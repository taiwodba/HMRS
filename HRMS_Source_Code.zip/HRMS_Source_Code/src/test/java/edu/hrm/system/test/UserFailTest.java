package edu.hrm.system.test;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.models.user.User;

public class UserFailTest extends TestCase {

	private Controller controller;

	@Before 
	public void setUp() {
		controller = new Controller();
		controller.init();
	}
	
	@Test
	public void testUnknownUser() {
		
		User user = controller.getUserController().authenticate("unknown", "unknown");
		// check if user authenticated. User is unknown
		assertTrue(user != null);
	}
	
}