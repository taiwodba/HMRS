package edu.hrm.system.test;


import java.util.List;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.models.user.User;

public class UserTest extends TestCase {

	private Controller controller;

	@Before 
	public void setUp() {
		controller = new Controller();
		controller.init();
	}
	
	@Test
	public void testAdminLogin() {
		
		User user = controller.getUserController().authenticate("admin", "admin");
		// check if user authenticated
		assertTrue(user != null);
		// check username
		assertEquals(user.getUsername(), "admin");
		// check if user is admin
		assertTrue(user.isAdmin());
	}
	
	
	@Test
	public void testIndividualUserLogin() {
		
		User user = controller.getUserController().authenticate("test", "test");
		// check if user authenticated
		assertTrue(user != null);
		// check username
		assertEquals(user.getUsername(), "test");
		// check if user is admin
		assertTrue(!user.isAdmin());
	}

	@Test
	public void testAllUsers() {
		
		List<User> users = controller.getUserController().getAll();
		// check if users exists
		assertTrue(users != null);
		// check if users is empty
		assertTrue(!users.isEmpty());
	}
}
