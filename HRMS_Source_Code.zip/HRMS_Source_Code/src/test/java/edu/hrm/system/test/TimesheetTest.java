package edu.hrm.system.test;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.models.timesheet.Timesheet;
import edu.hrm.system.models.timesheet.TimesheetStatus;
import junit.framework.TestCase;

public class TimesheetTest extends TestCase {

	private Controller controller;
	private Timesheet timesheet;

	@Before 
	public void setUp() {
		controller = new Controller();
		controller.init();
		// first setting user who created 
		Controller.user = controller.getUserController().authenticate("admin", "admin");
		// check if user authenticated
		assertTrue(Controller.user != null);
		// create test timesheet 50 weeks before today
		timesheet = controller.getTimesheetController().createTimesheet(DateUtils.addWeeks(new Date(), -50));
	}
	
	@Test
	public void testTimesheetCreation() {
		
		assertNotNull(timesheet);
		assertEquals(timesheet.getStatus(), TimesheetStatus.CREATED.toString());
		timesheet = controller.getTimesheetController().insertOrUpdateTimesheet(timesheet);
	}
	
	@Test
	public void testTimesheetGet() {
		// there is at least one timesheet created
		List<Timesheet> timesheets = controller.getTimesheetController().getTimesheets(DateUtils.addWeeks(new Date(), -50));
		assertFalse(timesheets.isEmpty());
	}
	
	@Test 
	public void testTimesheetApprove() {
		timesheet.setStatus(TimesheetStatus.APPROVED.toString());
		timesheet = controller.getTimesheetController().insertOrUpdateTimesheet(timesheet);
		assertEquals(timesheet.getStatus(), TimesheetStatus.APPROVED.toString());
	}
	
	
	@After
    public final void tearDown() {
		controller.getTimesheetController().delete(timesheet);
		timesheet = null;
		assertNull(timesheet); 
	}
}
