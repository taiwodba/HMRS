package edu.hrm.system.test;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.models.project.Project;
import junit.framework.TestCase;

public class ProjectTest extends TestCase {

	private static final String PROJECT_NAME = "Testing project";
	
	private Controller controller;
	private Project project;

	@Before 
	public void setUp() {
		controller = new Controller();
		controller.init();
		// first setting user who created 
		Controller.user = controller.getUserController().authenticate("admin", "admin");
		// check if user authenticated
		assertTrue(Controller.user != null);
		// creation of project
		project = new Project(PROJECT_NAME);
		project.setUser(Controller.user);
		project.setDescription("Testing project description");
		
		project = controller.getProjectController().insertOrUpdate(project);
	}
	
	
	
	@Test
	public void testProjectCreation() {
		assertNotNull(project.getProjectId());
	}
	
	@Test
	public void testProjectGet() {
		// there is at least one project created
		List<Project> projects = controller.getProjectController().getAll();
		assertFalse(projects.isEmpty());
	}
	
	@Test 
	public void testProjectName() {
		assertEquals(project.getName(), PROJECT_NAME);
	}
	
	
	@After
    public final void tearDown() {
		controller.getProjectController().delete(project);
		project = null;
		assertNull(project); 
	}
}
