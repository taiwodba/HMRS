package edu.hrm.system.views.common;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;

import com.vaadin.ui.ComboBox;

import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.common.IEntity;

@SuppressWarnings("serial")
public class EntitySelectField<T> extends ComboBox {

	@SuppressWarnings("unchecked")
	public EntitySelectField(String caption, Class<T> type) {
		setCaption(caption);
		setImmediate(true);
		
		Session session = HibernateUtils.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(type);
		List<T> entities = (List<T>)criteria.list();
		
		for(T entity : entities) {
			addItem(entity);
			setItemCaption(entity, ((IEntity)entity).toString());
		}
		
	}
	
	public void addItems(List<T> entities) {
		removeAllItems();
		for(T entity : entities) {
			addItem(entity);
			setItemCaption(entity, ((IEntity)entity).toString());
		}
	}
	
	public void set(T entity) {
		select(entity);
	}
	
	@SuppressWarnings("unchecked")
	public T getSelectedValue() {
		return (T) getValue();
	}
}
