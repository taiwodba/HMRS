package edu.hrm.system.views.activity;


import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.activity.Activity;
import edu.hrm.system.models.project.Project;
import edu.hrm.system.views.common.BasicWindow;
import edu.hrm.system.views.common.EntitySelectField;

@SuppressWarnings("serial")
public class AddEditActivityWindow extends BasicWindow {

    public static final String ID = "addeditactivity";
    private Activity activity;
    
	public AddEditActivityWindow(String caption, Activity activity, ActivityTable activityTable) {
		super(caption);
		this.activity = activity;
		setId(ID);
        setWidth("500px");
        Responsive.makeResponsive(this);
       
        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        
        Label section = new Label("Activity Info");
        section.addStyleName("h2");
        section.addStyleName("colored");
        formLayout.addComponent(section);
        // project info
        EntitySelectField<Project> projectSelectField = new EntitySelectField<Project>("Project", Project.class);
        
        TextField nameField = new TextField("Activity Name");
        nameField.setRequired(true);
        nameField.setRequiredError("Activity Name is required");
       
        formLayout.addComponents(projectSelectField, nameField);
        
        if(this.activity != null) {
        	nameField.setValue(this.activity.getName());
        	projectSelectField.set(this.activity.getProject());
        }
        
        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Save", listener -> {
        	// validate user input
        	if(!nameField.isValid()) {
        		Notification.show("Please enter valid form data.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	// send user to controller for saving
        	if(this.activity == null) {
        		this.activity = new Activity();
        	}
        	this.activity.setProject(projectSelectField.getSelectedValue());
        	this.activity.setName(nameField.getValue());
        	
        	MainUI.getController().getActivityController().insertOrUpdate(this.activity);
        	
        	Notification.show("Successfully update activity", Notification.Type.TRAY_NOTIFICATION);
        	activityTable.setProject(projectSelectField.getSelectedValue()).refresh();
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        buttons.addComponent(closeButton);
        formLayout.addComponent(buttons);
        setContent(formLayout);
	}

	public static void open(String caption, Activity activity, ActivityTable activityTable) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new AddEditActivityWindow(caption, activity, activityTable);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}