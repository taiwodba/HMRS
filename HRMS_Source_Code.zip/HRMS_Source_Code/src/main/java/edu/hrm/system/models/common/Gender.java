package edu.hrm.system.models.common;

public enum Gender {
	MALE,
	FEMALE
}
