package edu.hrm.system.views.timesheet;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.vaadin.server.FontAwesome;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Panel;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.email.EmailSender;
import edu.hrm.system.models.activity.Activity;
import edu.hrm.system.models.leave.Leave;
import edu.hrm.system.models.project.Project;
import edu.hrm.system.models.timesheet.Timesheet;
import edu.hrm.system.models.timesheet.TimesheetStatus;
import edu.hrm.system.models.timesheet.Timesheetitem;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.DeleteEntityWindow;
import edu.hrm.system.views.common.EntitySelectField;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class TimesheetLayout extends HorizontalLayout implements IRefreshable{
	
	private EntitySelectField<Project> projectSelect;
	private EntitySelectField<Activity> activitySelect;
	private Map<Timesheetitem, TextField> timesheetItemTextFieldMap;
	private List<Timesheet> timesheets;
	private VerticalLayout mainLayout;
	private Timesheet timesheetToDelete;
	
	public TimesheetLayout() {
		this.timesheetItemTextFieldMap = new LinkedHashMap<>();
		this.timesheets = new ArrayList<>();
		this.mainLayout = new VerticalLayout();
		this.mainLayout.setSpacing(true);
		addComponent(this.mainLayout);
	}
	
	public void clear() {
		timesheetItemTextFieldMap.clear();
		timesheets.clear();
		mainLayout.removeAllComponents();
	}
	
	public void addTimesheet(Timesheet timesheet) {
		timesheets.add(timesheet);
		createLayout(timesheet);
	}
	
	private void createLayout(Timesheet timesheet) {
		Panel timesheetPanel = new Panel("Timesheet for week "+timesheet.getWeek()+". "+timesheet.getStartDate()+" - "+timesheet.getEndDate());
		if(timesheet.getStatus().equals(TimesheetStatus.APPROVED.toString())) {
			timesheetPanel.addStyleName("color1");
			timesheetPanel.setCaption("Timesheet for week "+timesheet.getWeek()+". "+timesheet.getStartDate()+" - "+timesheet.getEndDate()+". APPROVED");
		} else if(timesheet.getStatus().equals(TimesheetStatus.PENDING.toString())) {
			timesheetPanel.addStyleName("color2");
			timesheetPanel.setCaption("Timesheet for week "+timesheet.getWeek()+". "+timesheet.getStartDate()+" - "+timesheet.getEndDate()+". PENDING");
		} else if(timesheet.getStatus().equals(TimesheetStatus.REJECTED.toString())) {
			timesheetPanel.addStyleName("color3");
			timesheetPanel.setCaption("Timesheet for week "+timesheet.getWeek()+". "+timesheet.getStartDate()+" - "+timesheet.getEndDate()+". REJECTED");
		}
		
		HorizontalLayout horizontalLayout = new HorizontalLayout();
		horizontalLayout.setSpacing(true);
		horizontalLayout.setMargin(true);
		
		projectSelect = new EntitySelectField<Project>("Project", Project.class);
		if(timesheet.getProject()!=null) {
			projectSelect.set(timesheet.getProject());
		}
		activitySelect = new EntitySelectField<Activity>("Activity", Activity.class);
		if(timesheet.getActivity()!=null) {
			activitySelect.set(timesheet.getActivity());
		}
		projectSelect.addValueChangeListener(listener -> {
			Project project = (Project)listener.getProperty().getValue();
			if(project != null) {
				activitySelect.addItems(MainUI.getController().getActivityController().getActivityForProject(project));
			}
		});
		
		// add components
		if(!Controller.getCurrentUser().isManager() && (timesheet.getStatus().equals(TimesheetStatus.CREATED.toString()) || timesheet.getStatus().equals(TimesheetStatus.REJECTED.toString()))) {
			Button submitTimesheet = new Button("Submit timesheet", listener -> {
				User user = Controller.getCurrentUser();
				
				if(user.getManager() == null) {
					Notification.show("You can't submit timesheet because your manager is not defined.", Notification.Type.ERROR_MESSAGE);
					return;
				}
					
				timesheet.setStatus(TimesheetStatus.PENDING.toString());
				timesheet.setProject(projectSelect.getSelectedValue());
				timesheet.setActivity(activitySelect.getSelectedValue());
				timesheetToDelete = null;
				MainUI.getController().getTimesheetController().insertOrUpdateTimesheet(timesheet);
				Notification.show("Successfully submitted timesheet. Sending email...", Notification.Type.TRAY_NOTIFICATION);
				refresh();
				
				new EmailSender().send(user.getManager().getEmail(), "Timesheet from employee "+user.getFullName(), "Timesheet "+timesheet.getWeek()+" "+timesheet.getStartDate()+" "+timesheet.getEndDate()+" is submited from employee "+user.getFullName()+".");
			});
			submitTimesheet.addStyleName(ValoTheme.BUTTON_FRIENDLY);
			horizontalLayout.addComponent(submitTimesheet);
			horizontalLayout.setComponentAlignment(submitTimesheet, Alignment.BOTTOM_CENTER);
		} else if(timesheet.getStatus().equals(TimesheetStatus.PENDING.toString()) && Controller.getCurrentUser().isManager()) {
			Button approveTimesheet = new Button("Approve", listener -> {
				timesheet.setStatus(TimesheetStatus.APPROVED.toString());
				timesheet.setApproved(true);
				timesheetToDelete = null;
				MainUI.getController().getTimesheetController().insertOrUpdateTimesheet(timesheet);
				Notification.show("Timesheet successfully approved. Sending email...", Notification.Type.TRAY_NOTIFICATION);
				refresh();
				new EmailSender().send(timesheet.getUser().getEmail(), "Timesheet approved from manager "+Controller.getCurrentUser().getFullName(), "Timesheet "+timesheet.getWeek()+" "+timesheet.getStartDate()+" "+timesheet.getEndDate()+" is approved.");
				
			});
			approveTimesheet.addStyleName(ValoTheme.BUTTON_FRIENDLY);

			Button rejectTimesheet = new Button("Reject", listener -> {
				timesheet.setStatus(TimesheetStatus.REJECTED.toString());
				timesheet.setApproved(false);
				timesheetToDelete = null;
				MainUI.getController().getTimesheetController().insertOrUpdateTimesheet(timesheet);
				Notification.show("Timesheet successfully rejected. Sending email...", Notification.Type.TRAY_NOTIFICATION);
				refresh();
				new EmailSender().send(timesheet.getUser().getEmail(), "Timesheet rejected from manager "+Controller.getCurrentUser().getFullName(), "Timesheet "+timesheet.getWeek()+" "+timesheet.getStartDate()+" "+timesheet.getEndDate()+" is rejected.");

			});
			rejectTimesheet.addStyleName(ValoTheme.BUTTON_DANGER);
			
			horizontalLayout.addComponent(approveTimesheet);
			horizontalLayout.setComponentAlignment(approveTimesheet, Alignment.BOTTOM_CENTER);
			
			horizontalLayout.addComponent(rejectTimesheet);
			horizontalLayout.setComponentAlignment(rejectTimesheet, Alignment.BOTTOM_CENTER);
		}
		
		horizontalLayout.addComponents(projectSelect, activitySelect);
		
		DateFormat dayFormat = new SimpleDateFormat("dd.MM");
		BigDecimal totalHours = BigDecimal.ZERO;
		
		List<Leave> myApprovedLeaves = MainUI.getController().getLeaveController().getMyApprovedLeaves(Controller.getCurrentUser());
		
		for(Timesheetitem timesheetitem : new TreeSet<Timesheetitem>(timesheet.getTimesheetitems())) {
			
			TextField dayWorkHours = new TextField(dayFormat.format(timesheetitem.getDay()));
			dayWorkHours.setWidth("60px");
			int hours = timesheetitem.getWorkHours().intValue();
			int minutes = (int) ((timesheetitem.getWorkHours().doubleValue()%hours)*60);
			
			dayWorkHours.setValue(hours+":"+String.format("%02d", minutes));
			horizontalLayout.addComponent(dayWorkHours);
			timesheetItemTextFieldMap.put(timesheetitem, dayWorkHours);
			totalHours = totalHours.add(timesheetitem.getWorkHours());
			if(Controller.getCurrentUser().isManager()) {
				dayWorkHours.setEnabled(false);
			}
			
			for(Leave leave : myApprovedLeaves) {
				if(timesheetitem.getDay().compareTo(leave.getFromDate()) >= 0 && timesheetitem.getDay().compareTo(leave.getToDate()) <=0) {
					dayWorkHours.setEnabled(false);
					dayWorkHours.setIcon(FontAwesome.CALENDAR);
					dayWorkHours.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
					dayWorkHours.setValue("Vacation");
					dayWorkHours.setWidth("115px");
				}
			}
		}
		
		int hours = totalHours.intValue();
		int minutes = (int) ((totalHours.doubleValue()%hours)*60);
		final TextField totalHoursField = new TextField("TOTAL", hours+":"+String.format("%02d", minutes));
		totalHoursField.setWidth("60px");
		totalHoursField.setEnabled(false);
		
		horizontalLayout.addComponent(totalHoursField);
		
		if(!Controller.getCurrentUser().isManager() && (timesheet.getStatus().equals(TimesheetStatus.CREATED.toString()) || timesheet.getStatus().equals(TimesheetStatus.REJECTED.toString()))) {
			Button saveTimesheet = new Button("Save", listener -> {
				save(timesheet);
				BigDecimal totalHours2 = BigDecimal.ZERO;
				for(Timesheetitem timesheetitem : timesheet.getTimesheetitems()) {
					totalHours2 = totalHours2.add(timesheetitem.getWorkHours());
				}
				int hours2 = totalHours2.intValue();
				int minutes2 = (int) ((totalHours2.doubleValue()%hours2)*60);
				totalHoursField.setValue(hours2+":"+String.format("%02d", minutes2));
			});
			saveTimesheet.addStyleName(ValoTheme.BUTTON_PRIMARY);
			horizontalLayout.addComponent(saveTimesheet);
			Button deleteTimesheet = new Button("Delete", listener -> {
				DeleteEntityWindow.open("Delete timesheet", timesheetToDelete = timesheet, TimesheetLayout.this);
			});
			deleteTimesheet.addStyleName(ValoTheme.BUTTON_DANGER);
			horizontalLayout.addComponent(deleteTimesheet);
			
			horizontalLayout.setComponentAlignment(saveTimesheet, Alignment.BOTTOM_CENTER);
			horizontalLayout.setComponentAlignment(deleteTimesheet, Alignment.BOTTOM_CENTER);
		}
		
		timesheetPanel.setContent(horizontalLayout);
		mainLayout.addComponent(timesheetPanel);
	}

	private void save(Timesheet timesheet) {
		
		if(MainUI.getController().getTimesheetController().getTimesheet(timesheet, projectSelect.getSelectedValue(), activitySelect.getSelectedValue()) != null) {
			Notification.show("Timesheet with the same project and activity already exists", Notification.Type.ERROR_MESSAGE);
			return;	
		}
			
		timesheet.setProject(projectSelect.getSelectedValue());
		timesheet.setActivity(activitySelect.getSelectedValue());
		
		MainUI.getController().getTimesheetController().insertOrUpdateTimesheet(timesheet);
		
		for(Timesheetitem timesheetitem : timesheet.getTimesheetitems()) {
			TextField itemField = timesheetItemTextFieldMap.get(timesheetitem);
			if(!itemField.isEnabled()) {
				continue;
			}
			BigDecimal workHours = timesheetitem.getWorkHours();
			try {
				// check for decimal input
				workHours = BigDecimal.valueOf(Double.parseDouble(itemField.getValue()));
				if(workHours.intValue() < 0 || workHours.intValue() > 23) {
					Notification.show("Hours can't be negative and can't be greater then 23.", Notification.Type.ERROR_MESSAGE);
					return;	
				}
			} catch(NumberFormatException exp) {
				// check for string input
				String[] splitted = itemField.getValue().split(":");
				if(splitted.length == 1) {
					try {
						workHours = BigDecimal.valueOf(Double.parseDouble(splitted[0]));
					} catch(NumberFormatException exp2) {
						Notification.show("Please input valid work hours. Decimal format or HH:mm format.", Notification.Type.ERROR_MESSAGE);
						return;
					}
				} else if(splitted.length == 2) {
					try {
						Double hours = Double.parseDouble(splitted[0]);
						Double minutes = Double.parseDouble(splitted[1]);
						if(hours.intValue() < 0 || hours.intValue() > 23) {
							Notification.show("Hours can't be negative and can't be greater then 23.", Notification.Type.ERROR_MESSAGE);
							return;	
						}
						if(minutes.intValue() < 0 || minutes.intValue() > 59) {
							Notification.show("Minutes can't be negative and can't be greater then 59.", Notification.Type.ERROR_MESSAGE);
							return;	
						}
						workHours = BigDecimal.valueOf(hours+minutes/60);
						
					} catch(NumberFormatException exp2) {
						Notification.show("Please input valid work hours. Decimal format or HH:mm format.", Notification.Type.ERROR_MESSAGE);
						return;
					}
				} else {
					Notification.show("Please input valid work hours. Decimal format or HH:mm format.", Notification.Type.ERROR_MESSAGE);
					return;
				}
			}
			workHours = workHours.setScale(2, RoundingMode.CEILING);
			timesheetitem.setWorkHours(workHours);
		}
		for(Timesheetitem timesheetitem : timesheet.getTimesheetitems()) {
			MainUI.getController().getTimesheetController().insertOrUpdateTimesheetItem(timesheetitem);
		}
		Notification.show("Timesheet successfully updated.", Notification.Type.TRAY_NOTIFICATION);
	}

	private void removeTimesheet(Timesheet timesheet) {
		timesheetItemTextFieldMap.clear();
		if(timesheets.contains(timesheet)) {
			timesheets.remove(timesheet);
		}
		mainLayout.removeAllComponents();
	}

	@Override
	public void refresh() {
		removeTimesheet(timesheetToDelete);
		for(Timesheet timesheet : timesheets) {
			createLayout(timesheet);
		}
	}
	
}
