package edu.hrm.system.views.project;

import org.apache.commons.lang3.StringUtils;

import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.project.Project;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.BasicWindow;
import edu.hrm.system.views.common.EntitySelectField;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class AddEditProjectWindow extends BasicWindow {

    public static final String ID = "addeditproject";
    private Project project;
    
	public AddEditProjectWindow(String caption, Project project, IRefreshable refresher) {
		super(caption);
		this.project = project;
		setId(ID);
        setWidth("500px");
        Responsive.makeResponsive(this);
       
        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        
        Label section = new Label("Project Info");
        section.addStyleName("h2");
        section.addStyleName("colored");
        formLayout.addComponent(section);
        // organization info
        EntitySelectField<User> userSelectField = new EntitySelectField<User>("User", User.class);
        
        TextField nameField = new TextField("Project Name");
        nameField.setRequired(true);
        nameField.setRequiredError("Project Name is required");
        
        TextArea descriptionField = new TextArea("Project Description");
        descriptionField.setHeight("100px");
        
        formLayout.addComponents(userSelectField, nameField, descriptionField);
        
        if(this.project != null) {
        	nameField.setValue(this.project.getName());
        	descriptionField.setValue(StringUtils.defaultIfEmpty(this.project.getDescription(),""));
        	userSelectField.set(this.project.getUser());
        }
        
        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Save", listener -> {
        	// validate user input
        	if(!nameField.isValid() || !descriptionField.isValid()) {
        		Notification.show("Please enter valid form data.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	// send user to controller for saving
        	if(this.project == null) {
        		this.project = new Project();
        	}
        	this.project.setUser(userSelectField.getSelectedValue());
        	this.project.setName(nameField.getValue());
        	this.project.setDescription(descriptionField.getValue());
        	
        	MainUI.getController().getProjectController().insertOrUpdate(this.project);
        	
        	Notification.show("Successfully update project", Notification.Type.TRAY_NOTIFICATION);
        	refresher.refresh();
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        buttons.addComponent(closeButton);
        formLayout.addComponent(buttons);
        setContent(formLayout);
	}

	public static void open(String caption, Project project, IRefreshable refresher) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new AddEditProjectWindow(caption, project, refresher);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}