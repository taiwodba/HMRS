package edu.hrm.system.views.leave.calendar;

import java.util.Date;

import com.vaadin.shared.ui.datefield.Resolution;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.PopupDateField;

@SuppressWarnings("serial")
public class CalendarMonthYearComponent extends HorizontalLayout {

	private Button previousMonthButton;
	private Button nextMonthButton;
	private PopupDateField monthYearDateField;

	public CalendarMonthYearComponent() {
		initLayout();
	}
	
	private void initLayout() {
		setWidth("100%");
		setMargin(true);

		addComponent(previousMonthButton = new Button("Previous month"));
		setComponentAlignment(previousMonthButton, Alignment.MIDDLE_LEFT);

		addComponent(monthYearDateField = new PopupDateField());
		setComponentAlignment(monthYearDateField, Alignment.MIDDLE_CENTER);
		monthYearDateField.setValue(new Date());
		monthYearDateField.setImmediate(true);
		monthYearDateField.setResolution(Resolution.MONTH);

		addComponent(nextMonthButton = new Button("Next month"));
		setComponentAlignment(nextMonthButton, Alignment.MIDDLE_RIGHT);
	}

	public Button getPreviousMonthButton() {
		return previousMonthButton;
	}

	public Button getNextMonthButton() {
		return nextMonthButton;
	}

	public PopupDateField getMonthYearDateField() {
		return monthYearDateField;
	}
}
