package edu.hrm.system.views.leave.balance;

import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;

@SuppressWarnings("serial")
public class LeaveBalanceTab extends VerticalLayout {

	private LeaveBalanceTable leaveBalanceTable = new LeaveBalanceTable();
	
	public LeaveBalanceTab() {
		setSpacing(true);
		setCaption("Leave Balance");
		
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Leave Balance");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);

		formLayout.addComponent(formLabel);	
		
		VerticalLayout tableLayout = new VerticalLayout();
		tableLayout.setMargin(true);
		tableLayout.setSpacing(true);
		
		Button addLeaveBalanceButton = new Button("Add leave balance", listener -> {
			AddEditLeaveBalanceWindow.open("Add new leave balance", null, leaveBalanceTable);
		});
		addLeaveBalanceButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);

		leaveBalanceTable.createDataSource(MainUI.getController().getLeaveController().createLeaveBalanceContainer(MainUI.getController().getLeaveController().getMyLeaveBalance(null)));
		tableLayout.addComponent(addLeaveBalanceButton);
		tableLayout.addComponent(leaveBalanceTable);
		
		
		addComponent(formLayout);
		addComponent(tableLayout);
	}

}
