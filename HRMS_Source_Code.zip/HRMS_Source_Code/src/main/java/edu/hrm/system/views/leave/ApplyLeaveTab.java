package edu.hrm.system.views.leave;

import org.hibernate.exception.ConstraintViolationException;



import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;



import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.email.EmailSender;
import edu.hrm.system.models.leave.Leavetype;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.BasicContentWindow;
import edu.hrm.system.views.common.EntitySelectField;
import edu.hrm.system.views.leave.balance.LeaveBalanceTable;

@SuppressWarnings("serial")
public class ApplyLeaveTab extends VerticalLayout {

	private LeaveBalanceTable leaveBalanceTable = new LeaveBalanceTable();
	
	public ApplyLeaveTab() {
		setSpacing(true);
		setCaption("Apply Leave");
		
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Apply Leave");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);

		formLayout.addComponent(formLabel);
		
		EntitySelectField<Leavetype> leaveTypeSelectField = new EntitySelectField<Leavetype>("Leave Type", Leavetype.class);
		leaveTypeSelectField.setWidth("250px");
		leaveTypeSelectField.setRequired(true);
		leaveTypeSelectField.setRequiredError("Leave type is required");
		
		DateField fromDate = new DateField("From Date");
		fromDate.setRequired(true);
		fromDate.setRequiredError("From date is required");
        DateField toDate = new DateField("To Date");
        toDate.setRequired(true);
        toDate.setRequiredError("To date is required");
	        
        TextField workingDaysField = new TextField("Working Days");
        workingDaysField.setWidth("250px");
        workingDaysField.setRequired(true);
        workingDaysField.setRequiredError("Working days is required");
        TextArea commentField = new TextArea("Comment");
        commentField.setHeight("100px");
        commentField.setWidth("250px");
        
        Button applyLeaveButton = new Button("Apply", listener -> {
        	User user = Controller.getCurrentUser();
        	
        	if(!leaveTypeSelectField.isValid() || !fromDate.isValid() || !toDate.isValid() || !workingDaysField.isValid()) {
        		Notification.show("Form data invalid. Please input valid data.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	Integer workingDays = 0;
        	try {
        		workingDays = Integer.parseInt(workingDaysField.getValue());
        	} catch (NumberFormatException e) {
        		Notification.show("Wrong input working days. Please input number.", Notification.Type.WARNING_MESSAGE);
        		return;
			}
        	if(!MainUI.getController().getLeaveController().checkBalance(leaveTypeSelectField.getSelectedValue(), fromDate.getValue(), toDate.getValue(), workingDays)) {
        		Notification.show("You exceeded your leave balance limit. Please contact administrator.", Notification.Type.ERROR_MESSAGE);
        		return;
        	}
        	try {
        		MainUI.getController().getLeaveController().applyLeave(leaveTypeSelectField.getSelectedValue(), fromDate.getValue(), toDate.getValue(), workingDays, commentField.getValue());
        	} catch(ConstraintViolationException ex) {
        		Notification.show("You already applied for vacation in the period "+fromDate.getValue()+" "+toDate.getValue(), Notification.Type.ERROR_MESSAGE);
        		return;
        	}
        	Notification.show("Leave successfully applied. Sending email...", Notification.Type.TRAY_NOTIFICATION);
        	String emailTo = user.getEmail();
        	if(user.getManager() != null) {
        		emailTo = user.getManager().getEmail();
        	}
        	new EmailSender().send(emailTo, "Applied leave, employee "+user.getFullName(), "Employee "+user.getFullName()+" applied leave from "+fromDate.getValue()+" to "+toDate.getValue()+".");
        	leaveTypeSelectField.set(null);
        	fromDate.clear();
        	toDate.clear();
        	workingDaysField.clear();
        	commentField.clear();
        });
        applyLeaveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        
        Button checkBalanceButton = new Button("Check balance", listener -> {
        	leaveBalanceTable.createDataSource(MainUI.getController().getLeaveController().createLeaveBalanceContainer(MainUI.getController().getLeaveController().getMyLeaveBalance(Controller.getCurrentUser())));
        	VerticalLayout tableLayout = new VerticalLayout(leaveBalanceTable);
        	BasicContentWindow.open("My leave balance", "960px", tableLayout);
		});
		checkBalanceButton.addStyleName(ValoTheme.BUTTON_PRIMARY);
		HorizontalLayout buttons = new HorizontalLayout(applyLeaveButton, checkBalanceButton);
		buttons.setSpacing(true);
        
        formLayout.addComponents(leaveTypeSelectField, fromDate, toDate, workingDaysField, commentField, buttons);
		addComponent(formLayout);
	}
}