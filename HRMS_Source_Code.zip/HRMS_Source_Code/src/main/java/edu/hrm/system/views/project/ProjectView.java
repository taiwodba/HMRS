package edu.hrm.system.views.project;

import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.project.Project;
import edu.hrm.system.views.activity.ActivityView;

@SuppressWarnings("serial")
public class ProjectView extends VerticalLayout {

	private ProjectTable projectTable = new ProjectTable();
	private ActivityView activityView = new ActivityView();
	
	public ProjectView() {
		setSpacing(true);
		setCaption("Projects");
		
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Overview of projects");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);

		formLayout.addComponent(formLabel);	
		
		
		VerticalLayout tableLayout = new VerticalLayout();
		tableLayout.setMargin(true);
		tableLayout.setSpacing(true);
		
		Button addProjectButton = new Button("Add project", listener -> {
			AddEditProjectWindow.open("Add new project", null, projectTable);
		});
		addProjectButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);

		projectTable.createDataSource(MainUI.getController().getProjectController().createContainer(MainUI.getController().getProjectController().getAll()));
		tableLayout.addComponent(addProjectButton);
		tableLayout.addComponent(projectTable);
		
		addComponent(formLayout);
		addComponent(tableLayout);
		
		addComponent(activityView);
		
		projectTable.addItemClickListener(listener -> {
			Project project = (Project)listener.getItemId();
			if(project != null) {
				activityView.getActivityTable().setProject(project).refresh();
			}
		});
	}
}