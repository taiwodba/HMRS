package edu.hrm.system.views.common;

import java.util.ArrayList;
import java.util.List;

import com.vaadin.data.util.IndexedContainer;
import com.vaadin.event.Action;
import com.vaadin.event.Action.Handler;
import com.vaadin.ui.Table;

@SuppressWarnings("serial")
public abstract class AbstractTable extends Table implements Handler {

	private List<Action> actions = new ArrayList<Action>();
	
	public AbstractTable() {
		setSizeFull();
        setSelectable(true);
        setImmediate(true);
        setColumnCollapsingAllowed(true);
        setColumnReorderingAllowed(true);
        addActionHandler(this);
	}
	
	
	@Override
	public Action[] getActions(Object target, Object sender) {
		return actions.toArray(new Action[actions.size()]);
	}

	protected void addAction(Action action){
		if(!actions.contains(action)) {
			actions.add(action);
		}
	}
	
	public List<Action> getActions() {
		return actions;
	}

	public abstract void createDataSource(IndexedContainer container);
}
