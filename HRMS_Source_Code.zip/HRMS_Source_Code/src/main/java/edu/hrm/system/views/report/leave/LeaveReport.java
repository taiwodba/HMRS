package edu.hrm.system.views.report.leave;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.model.ChartType;
import com.vaadin.addon.charts.model.Labels;
import com.vaadin.addon.charts.model.ListSeries;
import com.vaadin.addon.charts.model.PlotOptionsBar;
import com.vaadin.addon.charts.model.Title;
import com.vaadin.addon.charts.model.VerticalAlign;
import com.vaadin.addon.charts.model.XAxis;
import com.vaadin.addon.charts.model.YAxis;
import com.vaadin.ui.VerticalLayout;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.leave.Leave;
import edu.hrm.system.models.user.User;

@SuppressWarnings("serial")
public class LeaveReport extends VerticalLayout {

	private Chart barChart;
	
	public LeaveReport() {
		setSizeFull();
		setMargin(true);
	}
	
	public void refresh(User user, Date fromDate, Date toDate) {
		removeAllComponents();
		// create bar chart
		addComponent(barChart =  new Chart(ChartType.COLUMN));
		barChart.getConfiguration().setTitle("Attendance hours for employee "+user.getFullName());
		
		List<Leave> appliedLeaves = MainUI.getController().getLeaveController().getMyApprovedLeaves(user, fromDate, toDate);
		
		Calendar start = Calendar.getInstance();
		start.setTime(fromDate);
		Calendar end = Calendar.getInstance();
		end.setTime(toDate);
		end.add(Calendar.DATE, 1);

		DateFormat dateFormat = new SimpleDateFormat("dd MM");
		List<String> categories = new ArrayList<>();
		ListSeries listSeries = new ListSeries(user.getFullName());
		
		for (Date day = start.getTime(); start.before(end); start.add(Calendar.DATE, 1), day = start.getTime()) {
			int attendance = 8;
			for(Leave leave : appliedLeaves) {
				if(day.compareTo(leave.getFromDate()) >= 0 && day.compareTo(leave.getToDate()) <= 0) {
					attendance = 0;
					break;
				}
			}
			
			listSeries.addData(attendance);
			categories.add(dateFormat.format(day));
		}
		barChart.getConfiguration().addSeries(listSeries);
		PlotOptionsBar plot = new PlotOptionsBar();
        plot.setDataLabels(new Labels(true));
        barChart.getConfiguration().setPlotOptions(plot);
        
        XAxis x = new XAxis();
        String[] cats = new String[categories.size()];
        for(int i = 0; i < categories.size(); i++) {
        	cats[i] = categories.get(i);
        }
        x.setCategories(cats);
        barChart.getConfiguration().addxAxis(x);
        
        YAxis y = new YAxis();
        y.setMin(0);
        Title title = new Title("Attendance Hours");
        title.setVerticalAlign(VerticalAlign.HIGH);
        y.setTitle(title);
        barChart.getConfiguration().addyAxis(y);
		
	}
}
