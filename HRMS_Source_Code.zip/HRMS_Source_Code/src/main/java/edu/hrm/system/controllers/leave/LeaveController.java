package edu.hrm.system.controllers.leave;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;

import com.vaadin.data.util.IndexedContainer;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.leave.Leave;
import edu.hrm.system.models.leave.LeaveStatus;
import edu.hrm.system.models.leave.Leavebalance;
import edu.hrm.system.models.leave.Leavetype;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.leave.MyLeavesTable;
import edu.hrm.system.views.leave.balance.LeaveBalanceTable;

public class LeaveController {

	
	/*
	 * LEAVE BALANCE METHODS
	 */
	/*
	  * Insert or update leave balance
	  */
	public Leavebalance insertOrUpdate(Leavebalance leavebalance) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(leavebalance);
		hibernateTransaction.commit();
		session.close();
		return leavebalance;
	}
		
	/*
	 * Delete leave balance
	 */
	public void delete(Leavebalance leavebalance) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.delete(leavebalance);
		hibernateTransaction.commit();
		session.close();
	}
	/*
	 * Get all leave balances from database
	 */
	@SuppressWarnings("unchecked")
	public List<Leavebalance> getMyLeaveBalance(User user) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		String sql = "from edu.hrm.system.models.leave.Leavebalance leavebalance ";
		if(user != null) {
			sql += "where leavebalance.user = :user";
		}
		Query query = session.createQuery(sql);	
		if(user != null) {
			query.setParameter("user", user);
		}
		List<Leavebalance> leavebalances = (List<Leavebalance>)query.list();
		session.close();
		return leavebalances;
	}
	
	/*
	 * Get all leave balances from database
	 */
	@SuppressWarnings("unchecked")
	public Leavebalance getMyLeaveBalance(User user, Leavetype leavetype , Date fromDate, Date toDate) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		String sql = "from edu.hrm.system.models.leave.Leavebalance leavebalance where leavebalance.user = :user and leavebalance.leavetype = :leavetype and leavebalance.fromDate <= :fromDate and leavebalance.toDate >= :toDate order by leavebalance.leaveBalanceId desc";
		
		Query query = session.createQuery(sql);	
		query.setParameter("user", user);
		query.setParameter("leavetype", leavetype);
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		List<Leavebalance> leavebalances = (List<Leavebalance>)query.list();
		session.close();
		return leavebalances.isEmpty()?null:leavebalances.get(0);
	}
	
	 /*
    * Creating organization container
    */
   @SuppressWarnings("unchecked")
	public IndexedContainer createLeaveBalanceContainer(List<Leavebalance> leavebalances) {
		IndexedContainer container = new IndexedContainer();
		// creating properties
		for(LeaveBalanceTable.Columns property : LeaveBalanceTable.Columns.values()) {
			container.addContainerProperty(property.getColumnId(), property.getValueType(), null);
		}
		for(Leavebalance leavebalance : leavebalances) {
			container.addItem(leavebalance);
			
			container.getContainerProperty(leavebalance, LeaveBalanceTable.Columns.LEAVE_TYPE.getColumnId()).setValue(leavebalance.getLeavetype().getName());
			container.getContainerProperty(leavebalance, LeaveBalanceTable.Columns.USER.getColumnId()).setValue(leavebalance.getUser().getFullName());
			container.getContainerProperty(leavebalance, LeaveBalanceTable.Columns.FROM_DATE.getColumnId()).setValue(leavebalance.getFromDate());
			container.getContainerProperty(leavebalance, LeaveBalanceTable.Columns.TO_DATE.getColumnId()).setValue(leavebalance.getToDate());
			container.getContainerProperty(leavebalance, LeaveBalanceTable.Columns.WORKING_DAYS.getColumnId()).setValue(leavebalance.getWorkingDays());
	
		}
		return container;
	}
   
    @SuppressWarnings("unchecked")
	public List<Leave> getMyLeaves(User user) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		String sql = "from edu.hrm.system.models.leave.Leave leave ";
		if(user != null) {
			sql += "where leave.user = :user";
		}
		Query query = session.createQuery(sql);	
		if(user != null) {
			query.setParameter("user", user);
		}
		List<Leave> leaves = (List<Leave>)query.list();
		session.close();
		return leaves;
	}
	
	@SuppressWarnings("unchecked")
	public IndexedContainer createContainer(List<Leave> myLeaves) {
		IndexedContainer container = new IndexedContainer();
		// creating properties
		for(MyLeavesTable.Columns property : MyLeavesTable.Columns.values()) {
			container.addContainerProperty(property.getColumnId(), property.getValueType(), null);
		}
		for(Leave leave : myLeaves) {
			container.addItem(leave);
			
			container.getContainerProperty(leave, MyLeavesTable.Columns.LEAVE_TYPE.getColumnId()).setValue(leave.getLeavetype().getName());
			container.getContainerProperty(leave, MyLeavesTable.Columns.USER.getColumnId()).setValue(leave.getUser().getFullName());
			container.getContainerProperty(leave, MyLeavesTable.Columns.FROM_DATE.getColumnId()).setValue(leave.getFromDate());
			container.getContainerProperty(leave, MyLeavesTable.Columns.TO_DATE.getColumnId()).setValue(leave.getToDate());
			container.getContainerProperty(leave, MyLeavesTable.Columns.WORKING_DAYS.getColumnId()).setValue(leave.getWorkingDays());
			container.getContainerProperty(leave, MyLeavesTable.Columns.STATUS.getColumnId()).setValue(leave.getStatus());
			container.getContainerProperty(leave, MyLeavesTable.Columns.COMMENT.getColumnId()).setValue(leave.getComment());
			
		}
		return container;
	}
	
	/*
	 * Check balance 
	 */
	public boolean checkBalance(Leavetype leavetype, Date fromDate, Date toDate, int workingDays) {
		Leavebalance leavebalance = getMyLeaveBalance(Controller.getCurrentUser(), leavetype, fromDate, toDate);
		if(leavebalance == null) {
			return false;
		}
		List<Leave> myLeaves = getMyLeaves(Controller.getCurrentUser(), leavetype);
		
		int onHoliday = 0;
		for(Leave leave : myLeaves) {
			if(leavebalance.getFromDate().before(leave.getFromDate()) && leavebalance.getToDate().after(leave.getToDate())) {
				onHoliday += leave.getWorkingDays();
			}
		}
		
		if(onHoliday+workingDays > leavebalance.getWorkingDays()) {
			return false;
		}
		return true;
	}
	
	@SuppressWarnings("unchecked")
	public List<Leave> getMyLeaves(User user, Leavetype leavetype) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		String sql = "from edu.hrm.system.models.leave.Leave leave where leave.user = :user and leave.leavetype = :leavetype and (status = 'APPROVED' or status = 'PENDING')";
		
		Query query = session.createQuery(sql);	
		query.setParameter("user", user);
		query.setParameter("leavetype", leavetype);
		
		List<Leave> leaves = (List<Leave>)query.list();
		session.close();
		return leaves;
	}
	
	@SuppressWarnings("unchecked")
	public List<Leave> getMyApprovedLeaves(User user) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		String sql = "from edu.hrm.system.models.leave.Leave leave where leave.user = :user and status = 'APPROVED'";
		
		Query query = session.createQuery(sql);	
		query.setParameter("user", user);
		
		List<Leave> leaves = (List<Leave>)query.list();
		session.close();
		return leaves;
	}
	
	@SuppressWarnings("unchecked")
	public List<Leave> getMyApprovedLeaves(User user, Date fromDate, Date toDate) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		String sql = "from edu.hrm.system.models.leave.Leave leave where leave.user = :user and status = 'APPROVED' and leave.fromDate >= :fromDate and leave.toDate <= :toDate";
		
		Query query = session.createQuery(sql);	
		query.setParameter("user", user);
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		
		List<Leave> leaves = (List<Leave>)query.list();
		session.close();
		return leaves;
	}
	
	public void applyLeave(Leavetype leavetype, Date fromDate, Date toDate, Integer workingDays, String comment) throws ConstraintViolationException {
		Leave leave = new Leave();
		leave.setLeavetype(leavetype);
		leave.setUser(Controller.getCurrentUser());
		leave.setFromDate(fromDate);
		leave.setToDate(toDate);
		leave.setWorkingDays(workingDays);
		leave.setComment(comment);
		leave.setStatus(LeaveStatus.PENDING.toString());
		insertOrUpdate(leave);
	}
	
	/*
	  * Insert or update leave balance
	  */
	public Leave insertOrUpdate(Leave leave) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(leave);
		hibernateTransaction.commit();
		session.close();
		return leave;
	}
	
	
}
