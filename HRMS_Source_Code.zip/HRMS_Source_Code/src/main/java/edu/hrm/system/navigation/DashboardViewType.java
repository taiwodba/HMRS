package edu.hrm.system.navigation;


import com.vaadin.navigator.View;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Resource;

import edu.hrm.system.views.admin.AdminView;
import edu.hrm.system.views.dashboard.DashboardView;
import edu.hrm.system.views.leave.LeaveView;
import edu.hrm.system.views.leave.MyLeavesView;
import edu.hrm.system.views.report.ReportView;
import edu.hrm.system.views.timesheet.TimesheetView;
import edu.hrm.system.views.user.profile.MyDetailsView;

public enum DashboardViewType {
	
	DASHBOARD("dashboard", DashboardView.class, FontAwesome.HOME, true),
	MY_DETAILS("my details", MyDetailsView.class, FontAwesome.USER, true),
	TIMESHEET("timesheet", TimesheetView.class, FontAwesome.CLOCK_O, true),
	LEAVE("leave", LeaveView.class, FontAwesome.CALENDAR, true),
	MY_LEAVES("my leaves", MyLeavesView.class, FontAwesome.CALENDAR_O, true),
	REPORTS("reports", ReportView.class, FontAwesome.BAR_CHART_O, true),
	ADMIN("admin", AdminView.class, FontAwesome.USERS, true);

	    private final String viewName;
	    private final Class<? extends View> viewClass;
	    private final Resource icon;
	    private final boolean stateful;

	    private DashboardViewType(final String viewName,
	            final Class<? extends View> viewClass, final Resource icon,
	            final boolean stateful) {
	        this.viewName = viewName;
	        this.viewClass = viewClass;
	        this.icon = icon;
	        this.stateful = stateful;
	    }

	    public boolean isStateful() {
	        return stateful;
	    }

	    public String getViewName() {
	        return viewName;
	    }

	    public Class<? extends View> getViewClass() {
	        return viewClass;
	    }

	    public Resource getIcon() {
	        return icon;
	    }

	    public static DashboardViewType getByViewName(final String viewName) {
	        DashboardViewType result = null;
	        for (DashboardViewType viewType : values()) {
	            if (viewType.getViewName().equals(viewName)) {
	                result = viewType;
	                break;
	            }
	        }
	        return result;
	    }
}
