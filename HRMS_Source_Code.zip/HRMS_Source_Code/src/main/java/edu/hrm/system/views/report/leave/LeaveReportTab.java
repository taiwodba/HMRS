package edu.hrm.system.views.report.leave;

import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.EntitySelectField;

@SuppressWarnings("serial")
public class LeaveReportTab extends VerticalLayout  {

	private LeaveReport leaveReport = new LeaveReport();
	
	public LeaveReportTab() {
		setSpacing(true);
		setCaption("Attendance Report");
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Attendance Report");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);
		
		formLayout.addComponent(formLabel);	
		
		EntitySelectField<User> employee = new EntitySelectField<User>("Employee", User.class);
		employee.addItems(MainUI.getController().getUserController().getEmployeeUsers());
		DateField fromDate = new DateField("From Date");
		DateField toDate = new DateField("To Date");
		
		Button filterButton = new Button("Filter", listener -> {
			leaveReport.refresh(employee.getSelectedValue(), fromDate.getValue(), toDate.getValue());
		});
		filterButton.addStyleName(ValoTheme.BUTTON_PRIMARY);
		formLayout.addComponents(employee, fromDate, toDate, filterButton);
		
		addComponent(formLayout);
		addComponent(leaveReport);
	}
}
