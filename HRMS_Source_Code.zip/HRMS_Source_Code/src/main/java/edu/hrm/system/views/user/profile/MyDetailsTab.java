package edu.hrm.system.views.user.profile;

import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.models.user.User;
@SuppressWarnings("serial")
public class MyDetailsTab extends VerticalLayout {
	
	public MyDetailsTab(User user) {
		setSpacing(true);
		setCaption("My details");
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Overview my details");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);
		
		formLayout.addComponent(formLabel);	
		
		Label section = new Label("Personal Info");
        section.addStyleName("h2");
        section.addStyleName("colored");
        formLayout.addComponent(section);
        
        Label fullName = new Label(user.getFullName());
        fullName.setCaption("Full Name");
        
        Label username = new Label(user.getUsername());
        username.setCaption("Username");
        
        Label gender = new Label(user.getGender());
        gender.setCaption("Gender");
        
        Label birthDate = new Label(user.getDateOfBirth()!=null?user.getDateOfBirth().toString():"");
        birthDate.setCaption("Date Of Birth");
        
        Label status = new Label("Enabled");
        status.setCaption("Status");
        
        formLayout.addComponents(fullName, username, gender, birthDate);
        
        Label section2 = new Label("Manager info");
        section2.addStyleName("h3");
        section2.addStyleName("colored");
        
        Label manager = new Label("You are manager");
        manager.setCaption("Manager");
        if(user.getManager() != null) {
        	manager.setValue(user.getManager().toString());
        }
        formLayout.addComponents(section2, manager);
        
        Label section3 = new Label("Contact Info");
        section3.addStyleName("h3");
        section3.addStyleName("colored");
       
        Label address = new Label(user.getAddress()!=null?user.getAddress():"");
        address.setCaption("Address");
        
        Label telephone = new Label(user.getTelephoneNumber()!=null?user.getTelephoneNumber():"");
        telephone.setCaption("Telephone");
        
        Label email = new Label(user.getEmail()!=null?user.getEmail():"");
        email.setCaption("Email");
        
        formLayout.addComponents(section3, address, telephone, email);
        
		addComponent(formLayout);
	}

}
