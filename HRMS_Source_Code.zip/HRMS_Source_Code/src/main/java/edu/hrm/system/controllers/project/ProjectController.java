package edu.hrm.system.controllers.project;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.vaadin.data.util.IndexedContainer;

import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.project.Project;
import edu.hrm.system.views.project.ProjectTable;

public class ProjectController {

	/*
	 * Insert or update Project
	 */
	public Project insertOrUpdate(Project project) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(project);
		hibernateTransaction.commit();
		session.close();
		return project;
	}
		
	/*
	 * Delete Project
	 */
	public void delete(Project project) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.delete(project);
		hibernateTransaction.commit();
		session.close();
	}
	/*
	 * Get all Projects from database
	 */
	@SuppressWarnings("unchecked")
	public List<Project> getAll() {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(Project.class);
		List<Project> projects = (List<Project>)criteria.list();
		session.close();
		return projects;
	}
	
	 /*
    * Creating Project container
    */
   @SuppressWarnings("unchecked")
	public IndexedContainer createContainer(List<Project> projects) {
		IndexedContainer container = new IndexedContainer();
		// creating properties
		for(ProjectTable.Columns property : ProjectTable.Columns.values()) {
			container.addContainerProperty(property.getColumnId(), property.getValueType(), null);
		}
		for(Project project : projects) {
			container.addItem(project);
			
			container.getContainerProperty(project, ProjectTable.Columns.NAME.getColumnId()).setValue(project.getName());
			container.getContainerProperty(project, ProjectTable.Columns.DESCRIPTION.getColumnId()).setValue(project.getDescription());
			container.getContainerProperty(project, ProjectTable.Columns.ADMIN.getColumnId()).setValue(project.getUser().getFullName());
		}
		return container;
	}
}
