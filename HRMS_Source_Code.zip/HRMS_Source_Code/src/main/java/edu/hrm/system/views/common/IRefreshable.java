package edu.hrm.system.views.common;

public interface IRefreshable {

	void refresh();
}
