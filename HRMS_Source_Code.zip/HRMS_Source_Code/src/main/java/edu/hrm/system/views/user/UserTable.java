package edu.hrm.system.views.user;

import com.vaadin.data.util.IndexedContainer;
import com.vaadin.event.Action;
import com.vaadin.server.FontAwesome;
import com.vaadin.ui.Button;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Table;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.AbstractTable;
import edu.hrm.system.views.common.DeleteEntityWindow;
import edu.hrm.system.views.common.IRefreshable;
import edu.hrm.system.views.user.profile.AddEditUserWindow;

@SuppressWarnings("serial")
public class UserTable extends AbstractTable implements IRefreshable {

	public UserTable() {
		super();
		setPageLength(10);
		// adding action column for edit and delete row
		addGeneratedColumn(Columns.ID.getColumnId(), new ColumnGenerator() {			
			@Override
			public Object generateCell(Table source, Object itemId, Object columnId) {
				HorizontalLayout actionLayout = new HorizontalLayout();
				actionLayout.setSpacing(true);
				// edit button
				Button editButton = new Button(FontAwesome.EDIT);
				editButton.addStyleName(ValoTheme.BUTTON_QUIET);
				editButton.addStyleName(ValoTheme.BUTTON_TINY);
				editButton.addClickListener(listener -> {
					User user = (User)itemId;
					AddEditUserWindow.open("Edit user", user, UserTable.this);
				});
				// delete button
				Button deleteButton = new Button(FontAwesome.TRASH_O);
				deleteButton.addStyleName(ValoTheme.BUTTON_QUIET);
				deleteButton.addStyleName(ValoTheme.BUTTON_TINY);
				deleteButton.addClickListener(listener -> {
					User user = (User)itemId;
					DeleteEntityWindow.open("Delete user", user, UserTable.this);
				});
				
				actionLayout.addComponent(editButton);
				actionLayout.addComponent(deleteButton);
				
				return actionLayout;
			}
		});
		// add item click listener
		addItemClickListener(listener -> {
			if(listener.isDoubleClick()) {
				User user = (User)listener.getItemId();
				AddEditUserWindow.open("Edit user", user, UserTable.this);
			}
		});
	}

	@Override
	public void refresh() {
		createDataSource(MainUI.getController().getUserController().createContainer(MainUI.getController().getUserController().getAll()));
		refreshRowCache();
	}
	
	@Override
	public void handleAction(Action action, Object sender, Object target) {
		
	}

	@Override
	public void createDataSource(IndexedContainer container) {
		setContainerDataSource(container);
		setVisibleColumns(Columns.ID.getColumnId(), Columns.USERNAME.getColumnId(), Columns.FIRST_NAME.getColumnId(), Columns.LAST_NAME.getColumnId(), Columns.EMAIL.getColumnId(), Columns.JOB.getColumnId(), Columns.MANAGER.getColumnId(), Columns.ENABLED.getColumnId(), Columns.ADMIN.getColumnId());
		setColumnHeaders(Columns.ID.getColumnName(), Columns.USERNAME.getColumnName(), Columns.FIRST_NAME.getColumnName(), Columns.LAST_NAME.getColumnName(), Columns.EMAIL.getColumnName(), Columns.JOB.getColumnName(), Columns.MANAGER.getColumnName(), Columns.ENABLED.getColumnName(), Columns.ADMIN.getColumnName());
		setColumnWidth(Columns.ID.getColumnId(), 102);
	}

	
	public enum Columns {
		ID("userId", "Action", Integer.class),
		USERNAME("username", "Username", String.class),
		FIRST_NAME("firstName", "First Name", String.class),
		LAST_NAME("lastName", "Last Name", String.class),
		EMAIL("email", "Email", String.class),
		JOB("job","Job", String.class),
		MANAGER("manager","Manager", String.class),
		ENABLED("enabled", "Status", String.class),
		ADMIN("admin", "User Role", String.class);

		private String columnId;
        private String columnName;
        private Class<?> valueType;

       Columns(String columnId, String columnName, Class<?> valueType) {
       	this.columnId = columnId;
           this.columnName = columnName;
           this.valueType = valueType;
       }
       
       public String getColumnId() {
			return columnId;
		}

       public String getColumnName() {
           return columnName;
       }

       public Class<?> getValueType() {
           return valueType;
       }
   }
}
