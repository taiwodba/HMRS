package edu.hrm.system.views.job;

import org.apache.commons.lang3.StringUtils;

import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.job.Job;
import edu.hrm.system.models.organization.Organization;
import edu.hrm.system.views.common.BasicWindow;
import edu.hrm.system.views.common.EntitySelectField;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class AddEditJobWindow extends BasicWindow {

    public static final String ID = "addeditjob";
    private Job job;
    
	public AddEditJobWindow(String caption, Job job, IRefreshable refresher) {
		super(caption);
		this.job = job;
		setId(ID);
        setWidth("500px");
        Responsive.makeResponsive(this);
       
        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        
        Label section = new Label("Job Info");
        section.addStyleName("h2");
        section.addStyleName("colored");
        formLayout.addComponent(section);
        // organization info
        EntitySelectField<Organization> organizationSelectField = new EntitySelectField<Organization>("Organization", Organization.class);
        
        TextField nameField = new TextField("Job Name");
        nameField.setRequired(true);
        nameField.setRequiredError("Job Name is required");
        
        TextArea descriptionField = new TextArea("Job Description");
        descriptionField.setHeight("100px");
        
        formLayout.addComponents(organizationSelectField, nameField, descriptionField);
        
        if(this.job != null) {
        	nameField.setValue(this.job.getName());
        	descriptionField.setValue(StringUtils.defaultIfEmpty(this.job.getDescription(),""));
        	organizationSelectField.set(this.job.getOrganization());
        }
        
        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Save", listener -> {
        	// validate user input
        	if(!nameField.isValid() || !descriptionField.isValid()) {
        		Notification.show("Please enter valid form data.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	// send user to controller for saving
        	if(this.job == null) {
        		this.job = new Job();
        	}
        	this.job.setOrganization(organizationSelectField.getSelectedValue());
        	this.job.setName(nameField.getValue());
        	this.job.setDescription(descriptionField.getValue());
        	
        	MainUI.getController().getJobController().insertOrUpdate(this.job);
        	
        	Notification.show("Successfully update job", Notification.Type.TRAY_NOTIFICATION);
        	refresher.refresh();
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        buttons.addComponent(closeButton);
        formLayout.addComponent(buttons);
        setContent(formLayout);
	}

	public static void open(String caption, Job job, IRefreshable refresher) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new AddEditJobWindow(caption, job, refresher);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}
