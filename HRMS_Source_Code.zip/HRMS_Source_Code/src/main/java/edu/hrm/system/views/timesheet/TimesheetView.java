package edu.hrm.system.views.timesheet;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.events.DashboardEventBus;

@SuppressWarnings("serial")
public class TimesheetView extends TabSheet implements View {

	public TimesheetView() {
		setSizeFull();
		addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);
		DashboardEventBus.register(this);
	}
	
	@Override
	public void enter(ViewChangeEvent event) {
		removeAllComponents();
		// first tab timesheet view
		addTab(new TimesheetTab());
	}

}
