package edu.hrm.system.views.leave;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.views.leave.calendar.MyCalendarTab;
@SuppressWarnings("serial")
public class MyLeavesView extends TabSheet implements View {

	public MyLeavesView() {
		setSizeFull();
		addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);		DashboardEventBus.register(this);
	}
	
	@Override
	public void enter(ViewChangeEvent event) {
		removeAllComponents();
		
		// first tab my leaves table overview
		addTab(new MyLeavesTab());
		if(!Controller.getCurrentUser().isAdmin()) {
			addTab(new MyCalendarTab());
		}
	}
}

