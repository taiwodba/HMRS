package edu.hrm.system.views.common;

import com.vaadin.server.Responsive;
import com.vaadin.ui.Component;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;

import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;

@SuppressWarnings("serial")
public class BasicContentWindow extends BasicWindow {

	public static final String ID = "viewleavebalance";
	
	public BasicContentWindow(String caption, String width, Component content) {
		super(caption);
		setContent(content);
		setWidth(width);
		setId(ID);
		Responsive.makeResponsive(this);
	}
	
	public static void open(String caption, String width, Component component) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new BasicContentWindow(caption, width, component);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}
