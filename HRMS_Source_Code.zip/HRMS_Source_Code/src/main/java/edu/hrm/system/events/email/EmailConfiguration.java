package edu.hrm.system.events.email;

public class EmailConfiguration {
	public String host;
	public String port;
	public String auth;
	public String tls;
	public String userId;
	public String emailFrom;
	public String emailFromPassword;

	public String getHost() {
		return host;
	}

	public String getPort() {
		return port;
	}

	public String getAuth() {
		return auth;
	}

	public String getTls() {
		return tls;
	}

	public String getUserId() {
		return userId;
	}

	public String getEmailFrom() {
		return emailFrom;
	}

	public String getEmailFromPassword() {
		return emailFromPassword;
	}
}
