package edu.hrm.system.controllers.report;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.report.ProjectHours;
import edu.hrm.system.models.timesheet.Timesheetitem;
import edu.hrm.system.models.user.User;

public class ReportController {

	public List<ProjectHours> gerProjectsChartData(User user, Date fromDate, Date toDate) {
		
		List<Timesheetitem> timesheetitems = MainUI.getController().getTimesheetController().getTimesheetItems(user, fromDate, toDate);
		
		List<ProjectHours> projectHours = new ArrayList<>();
		
		for(Timesheetitem timesheetitem : timesheetitems) {
			ProjectHours projectHour = new ProjectHours(timesheetitem.getTimesheet().getProject());
			
			if(!projectHours.contains(projectHour)) {
				projectHours.add(projectHour);
			} else {
				projectHour = projectHours.get(projectHours.indexOf(projectHour));
			}
			projectHour.addHours(timesheetitem.getWorkHours());
		}
		return projectHours;
	}
}
