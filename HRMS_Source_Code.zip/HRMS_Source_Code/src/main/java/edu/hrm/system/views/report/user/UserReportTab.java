package edu.hrm.system.views.report.user;

import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.EntitySelectField;

@SuppressWarnings("serial")
public class UserReportTab extends VerticalLayout  {
	
	private UserReport userReport = new UserReport();
	
	public UserReportTab() {
		setSpacing(true);
		setCaption("Employee Report");
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Report on Breakdown on Employees Timesheet");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);
		
		formLayout.addComponent(formLabel);	
		
		EntitySelectField<User> user = new EntitySelectField<User>("Employee", User.class);
		user.addItems(MainUI.getController().getUserController().getEmployeeUsers());
		
		DateField fromDate = new DateField("From Date");
		DateField toDate = new DateField("To Date");
		
		Button filterButton = new Button("Filter", listener -> {
			userReport.refresh(user.getSelectedValue(), fromDate.getValue(), toDate.getValue());
		});
		filterButton.addStyleName(ValoTheme.BUTTON_PRIMARY);
		formLayout.addComponents(user, fromDate, toDate, filterButton);
		
		addComponent(formLayout);
		addComponent(userReport);
	}
}
