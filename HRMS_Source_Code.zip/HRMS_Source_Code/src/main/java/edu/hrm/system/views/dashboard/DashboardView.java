package edu.hrm.system.views.dashboard;


import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.ThemeResource;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.navigation.DashboardViewType;

@SuppressWarnings("serial")
public class DashboardView extends TabSheet implements View {

	
	public DashboardView() {
		setSizeFull();
		addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);
		DashboardEventBus.register(this);
		
		addTab(buildDrafts());
	}

	private Component buildDrafts() {
		final VerticalLayout allDrafts = new VerticalLayout();
		allDrafts.setSizeFull();
		allDrafts.setCaption("Dashboard");
        
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Welcome to the human resource timesheet system");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);

		formLayout.addComponent(formLabel);	
		formLayout.addComponent(new Label("<br />",ContentMode.HTML));
		
		HorizontalLayout actions = new HorizontalLayout();
		actions.setSpacing(true);
		Button applyLeaveButton = new Button("Apply Leave", listener->{
			UI.getCurrent().getNavigator().navigateTo(DashboardViewType.LEAVE.getViewName());
		});
		applyLeaveButton.setIcon(new ThemeResource("img/apply_leave_icon.png"));
		applyLeaveButton.addStyleName(ValoTheme.BUTTON_ICON_ALIGN_TOP);
		applyLeaveButton.addStyleName(ValoTheme.BUTTON_QUIET);
		if(Controller.getCurrentUser().isAdmin()) {
			applyLeaveButton.setCaption("Manage Leaves");
		}
		
		Button myLeaveButton = new Button("My Leave", listener->{
			UI.getCurrent().getNavigator().navigateTo(DashboardViewType.MY_LEAVES.getViewName());
		});
		myLeaveButton.setIcon(new ThemeResource("img/leave_icon.png"));
		myLeaveButton.addStyleName(ValoTheme.BUTTON_ICON_ALIGN_TOP);
		myLeaveButton.addStyleName(ValoTheme.BUTTON_QUIET);
		
		Button timesheetButton = new Button("My Timesheet", listener->{
			UI.getCurrent().getNavigator().navigateTo(DashboardViewType.TIMESHEET.getViewName());
		});
		timesheetButton.setIcon(new ThemeResource("img/timesheet_icon.png"));
		timesheetButton.addStyleName(ValoTheme.BUTTON_ICON_ALIGN_TOP);
		timesheetButton.addStyleName(ValoTheme.BUTTON_QUIET);
		
		actions.addComponent(applyLeaveButton);
		actions.addComponent(myLeaveButton);
		actions.addComponent(timesheetButton);
		
		formLayout.addComponent(actions);
		allDrafts.addComponent(formLayout);
		return allDrafts;
	}

	@Override
	public void enter(final ViewChangeEvent event) {
		
	}
}
