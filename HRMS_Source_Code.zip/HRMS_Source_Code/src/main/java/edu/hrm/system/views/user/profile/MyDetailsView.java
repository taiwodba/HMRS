package edu.hrm.system.views.user.profile;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.models.user.User;

@SuppressWarnings("serial")
public class MyDetailsView extends TabSheet implements View {

	public MyDetailsView() {
		setSizeFull();
		addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);
		DashboardEventBus.register(this);
	}
	
	@Override
	public void enter(ViewChangeEvent event) {
		removeAllComponents();
		// first tab user view
		User user = Controller.getCurrentUser();
		
		if(user == null) {
			Notification.show("Non authenticate access", Notification.Type.ERROR_MESSAGE);
			return;
		}
		addTab(new MyDetailsTab(user));
		
	}

}
