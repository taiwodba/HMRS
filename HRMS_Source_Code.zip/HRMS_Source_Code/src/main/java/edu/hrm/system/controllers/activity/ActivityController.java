package edu.hrm.system.controllers.activity;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.vaadin.data.util.IndexedContainer;

import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.activity.Activity;
import edu.hrm.system.models.project.Project;
import edu.hrm.system.views.activity.ActivityTable;

public class ActivityController {

	/*
	 * Insert or update Activity
	 */
	public Activity insertOrUpdate(Activity activity) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(activity);
		hibernateTransaction.commit();
		session.close();
		return activity;
	}
		
	/*
	 * Delete Activity
	 */
	public void delete(Activity activity) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.delete(activity);
		hibernateTransaction.commit();
		session.close();
	}
	/*
	 * Get all Activity from database
	 */
	@SuppressWarnings("unchecked")
	public List<Activity> getAll() {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(Activity.class);
		List<Activity> activities = (List<Activity>)criteria.list();
		session.close();
		return activities;
	}
	
	/*
	 * Get activities for related project
	 */
	@SuppressWarnings("unchecked")
	public List<Activity> getActivityForProject(Project project) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Query query = session.createQuery("from edu.hrm.system.models.activity.Activity activity where activity.project = :project");	
		query.setParameter("project", project);
		List<Activity> activities = (List<Activity>)query.list();
		session.close();
		return activities;
	}
	 /*
    * Creating Activity container
    */
   @SuppressWarnings("unchecked")
	public IndexedContainer createContainer(List<Activity> activities) {
		IndexedContainer container = new IndexedContainer();
		// creating properties
		for(ActivityTable.Columns property : ActivityTable.Columns.values()) {
			container.addContainerProperty(property.getColumnId(), property.getValueType(), null);
		}
		for(Activity activity : activities) {
			container.addItem(activity);
			
			container.getContainerProperty(activity, ActivityTable.Columns.NAME.getColumnId()).setValue(activity.getName());
			container.getContainerProperty(activity, ActivityTable.Columns.PROJECT.getColumnId()).setValue(activity.getProject().getName());
		}
		return container;
	}

}
