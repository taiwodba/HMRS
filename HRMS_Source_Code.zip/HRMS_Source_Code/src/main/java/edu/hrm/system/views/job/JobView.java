package edu.hrm.system.views.job;

import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;

@SuppressWarnings("serial")
public class JobView extends VerticalLayout {

	private JobTable jobTable = new JobTable();
	
	public JobView() {
		setSpacing(true);
		setCaption("Jobs");
		
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Overview of jobs");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);

		formLayout.addComponent(formLabel);	
		
		VerticalLayout tableLayout = new VerticalLayout();
		tableLayout.setMargin(true);
		tableLayout.setSpacing(true);
		
		Button addJobButton = new Button("Add job", listener -> {
			AddEditJobWindow.open("Add new job", null, jobTable);
		});
		addJobButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);

		jobTable.createDataSource(MainUI.getController().getJobController().createContainer(MainUI.getController().getJobController().getAll()));
		tableLayout.addComponent(addJobButton);
		tableLayout.addComponent(jobTable);
		
		
		addComponent(formLayout);
		addComponent(tableLayout);
	}

}