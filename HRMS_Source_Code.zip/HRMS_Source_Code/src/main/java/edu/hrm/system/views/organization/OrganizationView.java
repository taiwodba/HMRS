package edu.hrm.system.views.organization;

import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;

@SuppressWarnings("serial")
public class OrganizationView extends VerticalLayout {

	private OrganizationTable organizationTable = new OrganizationTable();
	
	public OrganizationView() {
		setSpacing(true);
		setCaption("Organizations");
		
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Overview of organizations");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);

		formLayout.addComponent(formLabel);	
		
		
		VerticalLayout tableLayout = new VerticalLayout();
		tableLayout.setMargin(true);
		tableLayout.setSpacing(true);
		
		Button addOrganizationButton = new Button("Add organization", listener -> {
			AddEditOrganizationWindow.open("Add new organization", null, organizationTable);
		});
		addOrganizationButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);

		organizationTable.createDataSource(MainUI.getController().getOrganizationController().createContainer(MainUI.getController().getOrganizationController().getAll()));
		tableLayout.addComponent(addOrganizationButton);
		tableLayout.addComponent(organizationTable);
		
		
		addComponent(formLayout);
		addComponent(tableLayout);
	}

}