package edu.hrm.system.views.user.profile;



import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.user.UserController;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.BasicWindow;

@SuppressWarnings("serial")
public class ProfilePreferencesWindow extends BasicWindow {

    public static final String ID = "profilepreferenceswindow";

    private ProfilePreferencesWindow(User user) {
        super("Change password");
        setId(ID);
        setWidth("400px");
        Responsive.makeResponsive(this);

        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        formLayout.setSpacing(true);
        
        Label usernameLabel = new Label(user.getUsername());
        usernameLabel.setCaption("Username");
        formLayout.addComponent(usernameLabel);
        
        
        final PasswordField currentPasswordField = new PasswordField("Current password");
        formLayout.addComponent(currentPasswordField);
        
        final PasswordField newPasswordField = new PasswordField("New password");
        formLayout.addComponent(newPasswordField);
        
        final PasswordField repeatNewPasswordField = new PasswordField("Repeat new password");
        formLayout.addComponent(repeatNewPasswordField);

        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Save", listener -> {
        	
        	if(!user.getPassword().equals(UserController.md5Hash(currentPasswordField.getValue()))) {
        		Notification.show("Incorrect current password. Please enter again.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	
        	if(!newPasswordField.getValue().equals(repeatNewPasswordField.getValue()) || newPasswordField.getValue().isEmpty()) {
        		Notification.show("Password fields doesn't match.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	user.setPassword(UserController.md5Hash(newPasswordField.getValue()));
        	MainUI.getController().getUserController().insertOrUpdate(user);
        	Notification.show("Password successfully changed", Notification.Type.TRAY_NOTIFICATION);
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        closeButton.addStyleName(ValoTheme.BUTTON_DANGER);
        buttons.addComponent(closeButton);
      
        formLayout.addComponent(buttons);
        setContent(formLayout);

    }


    public static void open(User user) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new ProfilePreferencesWindow(user);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}
