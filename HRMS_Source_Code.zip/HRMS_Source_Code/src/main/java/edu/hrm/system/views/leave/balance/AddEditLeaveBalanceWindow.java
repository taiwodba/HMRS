package edu.hrm.system.views.leave.balance;


import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.leave.Leavebalance;
import edu.hrm.system.models.leave.Leavetype;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.BasicWindow;
import edu.hrm.system.views.common.EntitySelectField;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class AddEditLeaveBalanceWindow extends BasicWindow {

    public static final String ID = "addeditleavebalance";
    private Leavebalance leavebalance;
    
	public AddEditLeaveBalanceWindow(String caption, Leavebalance leavebalance, IRefreshable refresher) {
		super(caption);
		this.leavebalance = leavebalance;
		setId(ID);
        setWidth("500px");
        Responsive.makeResponsive(this);
       
        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        
        Label section = new Label("Leave Balance Info");
        section.addStyleName("h2");
        section.addStyleName("colored");
        formLayout.addComponent(section);
        // Leavetype info
        EntitySelectField<Leavetype> leaveTypeSelectField = new EntitySelectField<Leavetype>("Leave Type", Leavetype.class);
        // User info
        EntitySelectField<User> userSelectField = new EntitySelectField<User>("User", User.class);
        
        DateField fromDate = new DateField("From Date");
        DateField toDate = new DateField("To Date");
        
        TextField workingDaysField = new TextField("Working Days");
        
        formLayout.addComponents(leaveTypeSelectField, userSelectField, fromDate, toDate, workingDaysField);
        
        if(this.leavebalance != null) {
        	leaveTypeSelectField.set(leavebalance.getLeavetype());
        	userSelectField.set(leavebalance.getUser());
        	fromDate.setValue(leavebalance.getFromDate());
        	toDate.setValue(leavebalance.getToDate());
        	workingDaysField.setValue(String.valueOf(leavebalance.getWorkingDays()));
        }
        
        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Save", listener -> {
        	// validate user input
        	if(this.leavebalance == null) {
        		this.leavebalance = new Leavebalance();
        	}
        	this.leavebalance.setLeavetype(leaveTypeSelectField.getSelectedValue());
        	this.leavebalance.setUser(userSelectField.getSelectedValue());
        	this.leavebalance.setFromDate(fromDate.getValue());
        	this.leavebalance.setToDate(toDate.getValue());
        	try {
        		this.leavebalance.setWorkingDays(Integer.parseInt(workingDaysField.getValue()));
        	} catch(NumberFormatException e) {
        		Notification.show("Wrong working days input", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	
        	MainUI.getController().getLeaveController().insertOrUpdate(this.leavebalance);
        	
        	Notification.show("Successfully update leave balance", Notification.Type.TRAY_NOTIFICATION);
        	refresher.refresh();
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        buttons.addComponent(closeButton);
        formLayout.addComponent(buttons);
        setContent(formLayout);
	}

	public static void open(String caption, Leavebalance leavebalance, IRefreshable refresher) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new AddEditLeaveBalanceWindow(caption, leavebalance, refresher);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}
