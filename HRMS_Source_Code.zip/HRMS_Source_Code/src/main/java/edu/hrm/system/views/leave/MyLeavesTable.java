package edu.hrm.system.views.leave;

import java.util.Date;

import com.vaadin.data.util.IndexedContainer;
import com.vaadin.event.Action;
import com.vaadin.server.FontAwesome;
import com.vaadin.ui.Button;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Table;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.email.EmailSender;
import edu.hrm.system.models.leave.Leave;
import edu.hrm.system.models.leave.LeaveStatus;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.AbstractTable;
import edu.hrm.system.views.common.DeleteEntityWindow;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class MyLeavesTable extends AbstractTable implements IRefreshable {

	private User user;
	
	public MyLeavesTable() {
		super();
		setPageLength(10);
		// adding action column for edit and delete row
		addGeneratedColumn(Columns.ID.getColumnId(), new ColumnGenerator() {			
			@Override
			public Object generateCell(Table source, Object itemId, Object columnId) {
				Leave leave  = (Leave)itemId;
				HorizontalLayout actionLayout = new HorizontalLayout();
				actionLayout.setSpacing(true);
				// delete button
				Button deleteButton = new Button(FontAwesome.TRASH_O);
				deleteButton.addStyleName(ValoTheme.BUTTON_QUIET);
				deleteButton.addStyleName(ValoTheme.BUTTON_TINY);
				deleteButton.addClickListener(listener -> {
					DeleteEntityWindow.open("Delete leave", leave, MyLeavesTable.this);
				});
				if(leave.getStatus().equals(LeaveStatus.PENDING.toString())) {
					if(Controller.getCurrentUser().isManager()) {
						Button approveLeaveButton = new Button("Approve", listener -> {							
							leave.setStatus(LeaveStatus.APPROVED.toString());
							MainUI.getController().getLeaveController().insertOrUpdate(leave);
							Notification.show("Leave successfully approved. Sending email...", Notification.Type.TRAY_NOTIFICATION);
							refresh();							
							new EmailSender().send(leave.getUser().getEmail(), "Applied leave, employee "+leave.getUser().getFullName(), "Your leave from "+leave.getFromDate()+" to "+leave.getToDate()+" is approved.");
						});
						approveLeaveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
						approveLeaveButton.addStyleName(ValoTheme.BUTTON_TINY);

						Button rejectLeaveButton = new Button("Reject", listener -> {
							leave.setStatus(LeaveStatus.REJECTED.toString());
							MainUI.getController().getLeaveController().insertOrUpdate(leave);
							Notification.show("Leave successfully rejected. Sending email...", Notification.Type.TRAY_NOTIFICATION);
							refresh();
							new EmailSender().send(leave.getUser().getEmail(), "Applied leave, employee "+leave.getUser().getFullName(), "Your leave from "+leave.getFromDate()+" to "+leave.getToDate()+" is rejected.");
						});
						rejectLeaveButton.addStyleName(ValoTheme.BUTTON_DANGER);
						rejectLeaveButton.addStyleName(ValoTheme.BUTTON_TINY);
						
						actionLayout.addComponents(approveLeaveButton, rejectLeaveButton);

					} else {
						actionLayout.addComponent(deleteButton);
					}
				}
				
				return actionLayout;
			}
		});
		setCellStyleGenerator(new CellStyleGenerator() {
			
			@Override
			public String getStyle(Table source, Object itemId, Object propertyId) {
				Leave leave  = (Leave)itemId;
				if(leave.getStatus().equals(LeaveStatus.APPROVED.toString())) {
					return "highlight-approved";
				} else if(leave.getStatus().equals(LeaveStatus.REJECTED.toString())) {
					return "highlight-rejected";
				}
				return null;
			}
		});
		
	}

	@Override
	public void refresh() {
		createDataSource(MainUI.getController().getLeaveController().createContainer(MainUI.getController().getLeaveController().getMyLeaves(user)));
		refreshRowCache();
	}
	
	@Override
	public void handleAction(Action action, Object sender, Object target) {
		
	}

	@Override
	public void createDataSource(IndexedContainer container) {
		setContainerDataSource(container);
		setVisibleColumns(Columns.ID.getColumnId(), Columns.LEAVE_TYPE.getColumnId(), Columns.USER.getColumnId(), Columns.FROM_DATE.getColumnId(), Columns.TO_DATE.getColumnId(), Columns.WORKING_DAYS.getColumnId(), Columns.STATUS.getColumnId(), Columns.COMMENT.getColumnId());
		setColumnHeaders(Columns.ID.getColumnName(), Columns.LEAVE_TYPE.getColumnName(), Columns.USER.getColumnName(), Columns.FROM_DATE.getColumnName(), Columns.TO_DATE.getColumnId(), Columns.WORKING_DAYS.getColumnId(), Columns.STATUS.getColumnId(), Columns.COMMENT.getColumnId());
		setColumnWidth(Columns.ID.getColumnId(), 165);
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public enum Columns {
		ID("leaveId", "Action", Integer.class),
		LEAVE_TYPE("leavetype", "Leave Type", String.class),
		USER("user", "User", String.class),
		FROM_DATE("fromDate", "From Date", Date.class),
		TO_DATE("toDate", "To Date", Date.class),
		WORKING_DAYS("workingDays", "Working Days", Integer.class),
		STATUS("status", "Status", String.class),
		COMMENT("comment", "Comment", String.class);

		private String columnId;
        private String columnName;
        private Class<?> valueType;

       Columns(String columnId, String columnName, Class<?> valueType) {
       	this.columnId = columnId;
           this.columnName = columnName;
           this.valueType = valueType;
       }
       
       public String getColumnId() {
			return columnId;
		}

       public String getColumnName() {
           return columnName;
       }

       public Class<?> getValueType() {
           return valueType;
       }
   }
}