package edu.hrm.system.views.leave.calendar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.vaadin.ui.Calendar;
import com.vaadin.ui.components.calendar.event.CalendarEvent;
import com.vaadin.ui.components.calendar.event.CalendarEventProvider;

import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.Controller;
import edu.hrm.system.models.leave.Leave;

@SuppressWarnings("serial")
public class CalendarComponent extends Calendar  {

	public CalendarComponent() {
		setReadOnly(true);
		setSizeFull();
	}
	
	public void refresh(Date startDate, Date endDate, boolean isInit) {
		if (isInit) {
			setEventProvider(getCalendarEventProvider());
		}
		setStartDate(startDate);
		setEndDate(endDate);
	}
	
	private CalendarEventProvider getCalendarEventProvider() {
		return new CalendarEventProvider() {
			
			@Override
			public List<CalendarEvent> getEvents(Date startDate, Date endDate) {
				List<CalendarEvent> events = new ArrayList<>();
				
				List<Leave> myApprovedLeaves = MainUI.getController().getLeaveController().getMyApprovedLeaves(Controller.getCurrentUser(), startDate, endDate);
				
				for(Leave leave : myApprovedLeaves) {
					events.add(new LeaveCalendarEvent(leave.getFromDate(), leave.getToDate(), leave.getStatus()+" "+ leave.getLeavetype().toString(), leave.getComment()));
				}
				
				return events;
			}
		};
	}
}
