package edu.hrm.system.views.leave.balance;

import java.util.Date;

import com.vaadin.data.util.IndexedContainer;
import com.vaadin.event.Action;
import com.vaadin.server.FontAwesome;
import com.vaadin.ui.Button;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Table;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.Controller;
import edu.hrm.system.models.leave.Leavebalance;
import edu.hrm.system.views.common.AbstractTable;
import edu.hrm.system.views.common.DeleteEntityWindow;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class LeaveBalanceTable extends AbstractTable implements IRefreshable {

	public LeaveBalanceTable() {
		super();
		setPageLength(10);
		// adding action column for edit and delete row
		addGeneratedColumn(Columns.ID.getColumnId(), new ColumnGenerator() {			
			@Override
			public Object generateCell(Table source, Object itemId, Object columnId) {
				HorizontalLayout actionLayout = new HorizontalLayout();
				actionLayout.setSpacing(true);
				// edit button
				Button editButton = new Button(FontAwesome.EDIT);
				editButton.addStyleName(ValoTheme.BUTTON_QUIET);
				editButton.addStyleName(ValoTheme.BUTTON_TINY);
				editButton.addClickListener(listener -> {
					Leavebalance leavebalance  = (Leavebalance)itemId;
					AddEditLeaveBalanceWindow.open("Edit leave balance", leavebalance, LeaveBalanceTable.this);
				});
				// delete button
				Button deleteButton = new Button(FontAwesome.TRASH_O);
				deleteButton.addStyleName(ValoTheme.BUTTON_QUIET);
				deleteButton.addStyleName(ValoTheme.BUTTON_TINY);
				deleteButton.addClickListener(listener -> {
					Leavebalance leavebalance  = (Leavebalance)itemId;
					DeleteEntityWindow.open("Delete leave balance", leavebalance, LeaveBalanceTable.this);
				});
				if(Controller.getCurrentUser().isAdmin()) {
					actionLayout.addComponents(editButton,deleteButton);
				}
				return actionLayout;
			}
		});
		if(Controller.getCurrentUser().isAdmin()) {
			// add item click listener
			addItemClickListener(listener -> {
				if(listener.isDoubleClick()) {
					Leavebalance leavebalance  = (Leavebalance)listener.getItemId();
					AddEditLeaveBalanceWindow.open("Edit leave balance", leavebalance, LeaveBalanceTable.this);
				}
			});
		}
	}

	@Override
	public void refresh() {
		createDataSource(MainUI.getController().getLeaveController().createLeaveBalanceContainer(MainUI.getController().getLeaveController().getMyLeaveBalance(null)));
		refreshRowCache();
	}
	
	@Override
	public void handleAction(Action action, Object sender, Object target) {
		
	}

	@Override
	public void createDataSource(IndexedContainer container) {
		setContainerDataSource(container);
		setVisibleColumns(Columns.ID.getColumnId(), Columns.LEAVE_TYPE.getColumnId(), Columns.USER.getColumnId(), Columns.FROM_DATE.getColumnId(), Columns.TO_DATE.getColumnId(), Columns.WORKING_DAYS.getColumnId());
		setColumnHeaders(Columns.ID.getColumnName(), Columns.LEAVE_TYPE.getColumnName(), Columns.USER.getColumnName(), Columns.FROM_DATE.getColumnName(), Columns.TO_DATE.getColumnId(), Columns.WORKING_DAYS.getColumnId());
		setColumnWidth(Columns.ID.getColumnId(), 102);
	}

	
	public enum Columns {
		ID("leaveBalanceId", "Action", Integer.class),
		LEAVE_TYPE("leavetype", "Leave Type", String.class),
		USER("user", "User", String.class),
		FROM_DATE("fromDate", "From Date", Date.class),
		TO_DATE("toDate", "To Date", Date.class),
		WORKING_DAYS("workingDays", "Working Days", Integer.class);

		private String columnId;
        private String columnName;
        private Class<?> valueType;

       Columns(String columnId, String columnName, Class<?> valueType) {
       	this.columnId = columnId;
           this.columnName = columnName;
           this.valueType = valueType;
       }
       
       public String getColumnId() {
			return columnId;
		}

       public String getColumnName() {
           return columnName;
       }

       public Class<?> getValueType() {
           return valueType;
       }
   }
}