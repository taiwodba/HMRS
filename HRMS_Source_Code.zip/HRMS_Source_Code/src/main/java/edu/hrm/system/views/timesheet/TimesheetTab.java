package edu.hrm.system.views.timesheet;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.Controller;
import edu.hrm.system.models.timesheet.Timesheet;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.EntitySelectField;


@SuppressWarnings("serial")
public class TimesheetTab extends VerticalLayout {

	private TimesheetLayout timesheetLayout = new TimesheetLayout();
	private Button addTimesheetButton;
	private EntitySelectField<User> userSelect;
	
	public TimesheetTab() {
		setSpacing(true);
		setCaption("Timesheet");
		
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Overview of timesheets");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);

		formLayout.addComponent(formLabel);	
		
		VerticalLayout tableLayout = new VerticalLayout();
		tableLayout.setMargin(true);
		tableLayout.setSpacing(true);
		
		HorizontalLayout actionLayout = new HorizontalLayout();
		DateField dateField = new DateField();
		
		if(!Controller.getCurrentUser().isManager()) {
			addTimesheetButton = new Button("Add timesheet", listener -> {
				if(dateField.getValue() == null) {
					Notification.show("Please select date to create timesheet", Notification.Type.WARNING_MESSAGE);
					return;
				}
				Calendar calendarSelected = Calendar.getInstance();
				calendarSelected.setFirstDayOfWeek(Calendar.MONDAY);
				calendarSelected.setTime(dateField.getValue());
				calendarSelected.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
				Date calendarSelectedSunday = calendarSelected.getTime();
				
				Calendar calendarNow = Calendar.getInstance();
				calendarNow.setFirstDayOfWeek(Calendar.MONDAY);
				calendarNow.setTime(new Date());
				calendarNow.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
				Date calendarNowSunday = calendarNow.getTime();
				
				if(calendarNowSunday.before(calendarSelectedSunday)) {
					Notification.show("You can't create timesheet in future", Notification.Type.ERROR_MESSAGE);
					return;
				}
				
				Timesheet timesheet = MainUI.getController().getTimesheetController().createTimesheet(dateField.getValue());
				if(timesheet != null) {
					timesheetLayout.addTimesheet(timesheet);
					Notification.show("Timesheet for week "+timesheet.getWeek()+" is created.", Notification.Type.TRAY_NOTIFICATION);
				}
				
			});
			addTimesheetButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
		}
		Button filterTimesheetButton = new Button("Filter timesheet", listener -> {
			timesheetLayout.clear();
			List<Timesheet> timesheets = new ArrayList<>();
			
			if(!Controller.getCurrentUser().isManager()) {
				timesheets = MainUI.getController().getTimesheetController().getTimesheets(dateField.getValue());
			} else {
				if(userSelect.getSelectedValue() == null) {
					Notification.show("Please select user to show timesheet.", Notification.Type.WARNING_MESSAGE);
					return;
				}
				timesheets = MainUI.getController().getTimesheetController().getAdminTimesheets(dateField.getValue(), userSelect.getSelectedValue());
			}
		
			for(Timesheet timesheet : timesheets) {
				timesheetLayout.addTimesheet(timesheet);
			}
			
		});
		filterTimesheetButton.addStyleName(ValoTheme.BUTTON_PRIMARY);
		
		actionLayout.setSpacing(true);	
		actionLayout.addComponent(dateField);
		if(Controller.getCurrentUser().isManager()) { 
			userSelect = new EntitySelectField<User>(null, User.class);
			userSelect.addItems(MainUI.getController().getUserController().getEmployeeUsers());
			actionLayout.addComponent(userSelect);
		}
		actionLayout.addComponent(filterTimesheetButton);
		if(!Controller.getCurrentUser().isManager()) { 
			actionLayout.addComponent(addTimesheetButton);
		}
		
		tableLayout.addComponent(actionLayout);
		tableLayout.addComponent(timesheetLayout);
		
		addComponent(formLayout);
		addComponent(tableLayout);
	}

}