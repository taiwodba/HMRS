package edu.hrm.system.models.leave;

public enum LeaveStatus {

	PENDING,
	APPROVED,
	REJECTED
}
