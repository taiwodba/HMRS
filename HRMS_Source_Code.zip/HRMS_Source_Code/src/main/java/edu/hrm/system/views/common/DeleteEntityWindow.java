package edu.hrm.system.views.common;

import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.common.IEntity;

@SuppressWarnings("serial")
public class DeleteEntityWindow extends BasicWindow {

	public static final String ID = "deleteentity";
	
	public DeleteEntityWindow(String caption, IEntity  entity, IRefreshable refreshable) {
		super(caption);
		setId(ID);
		setWidth("300px");
        Responsive.makeResponsive(this);
        
        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        formLayout.setSpacing(true);
        formLayout.addComponent(new Label("You are about to the delete entity. Are You Sure?"));
        
        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Delete", listener -> {
        	entity.delete();
        	refreshable.refresh();
        	Notification.show("Entity successfully deleted", Notification.Type.TRAY_NOTIFICATION);
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_DANGER);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        buttons.addComponent(closeButton);
        formLayout.addComponent(buttons);
        setContent(formLayout);
	}

	public static void open(String caption, IEntity  entity, IRefreshable refresher) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new DeleteEntityWindow(caption, entity, refresher);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}
