package edu.hrm.system.views.user.profile;


import org.apache.commons.lang3.StringUtils;

import com.vaadin.data.Validator.InvalidValueException;
import com.vaadin.data.validator.EmailValidator;
import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.user.UserController;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.common.Gender;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.BasicWindow;
import edu.hrm.system.views.common.EntitySelectField;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class AddEditUserWindow extends BasicWindow {

    public static final String ID = "addedituser";
    private User user;
    
	public AddEditUserWindow(String caption, User user, IRefreshable refresher) {
		super(caption);
		this.user = user;
		setId(ID);
        setWidth("600px");
        Responsive.makeResponsive(this);
       
        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        
        Label section = new Label("Personal Info");
        section.addStyleName("h2");
        section.addStyleName("colored");
        formLayout.addComponent(section);
        // personal info
        TextField usernameField = new TextField("Username");
        usernameField.setRequired(true);
        usernameField.setRequiredError("Username is required");
        
        PasswordField passwordField = new PasswordField("Password");
        PasswordField repeatPasswordField = new PasswordField("Repeat Password");
        
        TextField firstNameField = new TextField("First name");
        firstNameField.setRequired(true);
        firstNameField.setRequiredError("First name is required");
        
        TextField lastNameField = new TextField("Last name");
        lastNameField.setRequired(true);
        lastNameField.setRequiredError("Last name is required");
        
        OptionGroup genderGroup = new OptionGroup("Gender");
        genderGroup.addStyleName("horizontal");
        for(Gender gender : Gender.values()) {
            genderGroup.addItem(gender);
        }
        genderGroup.select(Gender.MALE);
        
        DateField birthDate = new DateField("Date of Birth");
        
        CheckBox statusCheckBox = new CheckBox("Enabled", true);
        CheckBox adminCheckBox = new CheckBox("Is Admin");
        
        formLayout.addComponents(firstNameField, lastNameField, usernameField);
        if(this.user == null) {
        	formLayout.addComponents(passwordField, repeatPasswordField);
        }
        formLayout.addComponents(genderGroup, birthDate, statusCheckBox, adminCheckBox);
        
        // manager
        EntitySelectField<User> manager = new EntitySelectField<User>("Manager", User.class);
        manager.addItems(MainUI.getController().getUserController().getManagerUsers());
        
        Label section2 = new Label("Manager info");
        section2.addStyleName("h3");
        section2.addStyleName("colored");
        formLayout.addComponent(section2);
        formLayout.addComponent(manager);
        
        Label section3 = new Label("Contact Info");
        section3.addStyleName("h3");
        section3.addStyleName("colored");
        formLayout.addComponent(section3);
        // contact info
        TextField addressField = new TextField("Address");
        TextField telephoneField = new TextField("Telephone");
        TextField emailField = new TextField("Email");
       
        formLayout.addComponents(addressField, telephoneField, emailField);
        
        if(this.user != null) {
        	usernameField.setValue(this.user.getUsername());
        	firstNameField.setValue(this.user.getFirstName());
        	lastNameField.setValue(this.user.getLastName());
        	emailField.setValue(this.user.getEmail());
        	statusCheckBox.setValue(this.user.isEnabled());
        	adminCheckBox.setValue(this.user.isAdmin());
        	if(this.user.getManager() != null) {
        		manager.set(this.user.getManager());
        	}
        	
        	telephoneField.setValue(StringUtils.defaultIfEmpty(this.user.getTelephoneNumber(), ""));

        	addressField.setValue(StringUtils.defaultIfEmpty(this.user.getAddress(), ""));
        	
        	if(this.user.getGender().equals(Gender.FEMALE.toString())) {
        		genderGroup.select(Gender.FEMALE);
        	}
        	if(this.user.getDateOfBirth()!=null) {
        		birthDate.setValue(this.user.getDateOfBirth());
        	}
        }
        
        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Save", listener -> {
        	// validate user input
        	try {
	        	EmailValidator emailValidator = new EmailValidator("Wrong email input");
	    		emailValidator.validate(emailField.getValue());
	        } catch(InvalidValueException exp) {
        		Notification.show("Email address is not valid. Please enter valid email.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	if(!usernameField.isValid() || !firstNameField.isValid() || !lastNameField.isValid()) {
        		Notification.show("Please enter valid form data.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	if(this.user == null) {
	        	if(!passwordField.getValue().equals(repeatPasswordField.getValue()) || passwordField.getValue().isEmpty()) {
	        		Notification.show("Password field doesn't match.", Notification.Type.WARNING_MESSAGE);
	        		return;
	        	}
        	}
        	// send user to controller for saving
        	if(this.user == null) {
        		this.user = new User();
        		this.user.setPassword(UserController.md5Hash(passwordField.getValue()));
        	}
        	
        	this.user.setUsername(usernameField.getValue());
        	this.user.setFirstName(firstNameField.getValue());
        	this.user.setLastName(lastNameField.getValue());
        	this.user.setEmail(emailField.getValue());
        	this.user.setAdmin(adminCheckBox.getValue());
        	this.user.setEnabled(statusCheckBox.getValue());
        	this.user.setTelephoneNumber(telephoneField.getValue());
        	this.user.setAddress(addressField.getValue());
        	this.user.setDateOfBirth(birthDate.getValue());
        	this.user.setGender(genderGroup.getValue().toString());
        	this.user.setManager(manager.getSelectedValue());
        	
        	MainUI.getController().getUserController().insertOrUpdate(this.user);
        	Notification.show("Successfully update users", Notification.Type.TRAY_NOTIFICATION);
        	refresher.refresh();
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        buttons.addComponent(closeButton);
        formLayout.addComponent(buttons);
        setContent(formLayout);
	}

	public static void open(String caption, User user, IRefreshable refresher) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new AddEditUserWindow(caption, user, refresher);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}
