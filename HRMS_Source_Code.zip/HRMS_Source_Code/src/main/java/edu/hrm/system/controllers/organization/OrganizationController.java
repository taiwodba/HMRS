package edu.hrm.system.controllers.organization;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.vaadin.data.util.IndexedContainer;

import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.organization.Organization;
import edu.hrm.system.views.organization.OrganizationTable;

public class OrganizationController {

	 /*
	  * Insert or update organization
	  */
	public Organization insertOrUpdate(Organization organization) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(organization);
		hibernateTransaction.commit();
		session.close();
		return organization;
	}
		
	/*
	 * Delete Organization
	 */
	public void delete(Organization organization) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.delete(organization);
		hibernateTransaction.commit();
		session.close();
	}
	/*
	 * Get all organizations from database
	 */
	@SuppressWarnings("unchecked")
	public List<Organization> getAll() {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(Organization.class);
		List<Organization> organizations = (List<Organization>)criteria.list();
		session.close();
		return organizations;
	}
	
	 /*
     * Creating organization container
     */
    @SuppressWarnings("unchecked")
	public IndexedContainer createContainer(List<Organization> organizations) {
		IndexedContainer container = new IndexedContainer();
		// creating properties
		for(OrganizationTable.Columns property : OrganizationTable.Columns.values()) {
			container.addContainerProperty(property.getColumnId(), property.getValueType(), null);
		}
		for(Organization organization : organizations) {
			container.addItem(organization);
			
			container.getContainerProperty(organization, OrganizationTable.Columns.NAME.getColumnId()).setValue(organization.getName());
			container.getContainerProperty(organization, OrganizationTable.Columns.DESCRIPTION.getColumnId()).setValue(organization.getDescription());
	
		}
		return container;
	}

   
}
