package edu.hrm.system.views.report;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.views.report.leave.LeaveReportTab;
import edu.hrm.system.views.report.project.ProjectReportTab;
import edu.hrm.system.views.report.user.UserReportTab;

@SuppressWarnings("serial")
public class ReportView extends TabSheet implements View {

	public ReportView() {
		setSizeFull();
		addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);
		DashboardEventBus.register(this);
	}
	
	@Override
	public void enter(ViewChangeEvent event) {
		removeAllComponents();
		// first tab 
		if(!Controller.getCurrentUser().isManager()) {
			Notification.show("You don't have permission to view this url.", Notification.Type.ERROR_MESSAGE);
			return;
		}
		// first tab
		addTab(new ProjectReportTab());
		// second tab
		addTab(new UserReportTab());
		// third tab
		addTab(new LeaveReportTab());
	}

}
