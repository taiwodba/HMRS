package edu.hrm.system.models.common;

public interface IEntity {
	void delete();

	String toString();
}
