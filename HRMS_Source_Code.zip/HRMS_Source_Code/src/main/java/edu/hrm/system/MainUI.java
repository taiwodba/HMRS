package edu.hrm.system;

import javax.servlet.annotation.WebServlet;

import com.google.common.eventbus.Subscribe;
import com.vaadin.annotations.Theme;
import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.annotations.Widgetset;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinServlet;
import com.vaadin.server.VaadinSession;
import com.vaadin.server.Page.BrowserWindowResizeEvent;
import com.vaadin.ui.themes.ValoTheme;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.DashboardEvent.UserLoggedOutEvent;
import edu.hrm.system.events.DashboardEvent.UserLoginRequestedEvent;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.BrowserResizeEvent;
import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.dashboard.MainView;
import edu.hrm.system.views.user.login.LoginView;

/**
 *
 */
@SuppressWarnings("serial")
@Theme("dashboard")
@Widgetset("edu.hrm.system.MainAppWidgetset")
public class MainUI extends UI {

	private final DashboardEventBus dashboardEventbus = new DashboardEventBus();
	private final Controller controller = new Controller();
	
    @Override
    protected void init(VaadinRequest vaadinRequest) {
    	 addStyleName(ValoTheme.UI_WITH_MENU);
         DashboardEventBus.register(this);
         Responsive.makeResponsive(this);
         initControllers();
         updateContent();
         // Some views need to be aware of browser resize events so a
         // BrowserResizeEvent gets fired to the event bus on every occasion.
         Page.getCurrent().addBrowserWindowResizeListener(new Page.BrowserWindowResizeListener() {
             @Override
             public void browserWindowResized(final BrowserWindowResizeEvent event) {
                 DashboardEventBus.post(new BrowserResizeEvent());
             }
         });
    }

    private void initControllers() {
    	controller.init();
    }
    
    /**
     * Updates the correct content for this UI based on the current user status.
     * If the user is logged in with appropriate privileges, main view is shown.
     * Otherwise login view is shown.
     */
    private void updateContent() {
        User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
        if (user != null) {
            // Authenticated user
            setContent(new MainView());
            removeStyleName("loginview");
            getNavigator().navigateTo(getNavigator().getState());
        } else {
            setContent(new LoginView());
            addStyleName("loginview");
        }
    }
    
    @Subscribe
    public void userLoginRequested(final UserLoginRequestedEvent event) {
    	
    	User user = controller.getUserController().authenticate(event.getUserName(), event.getPassword());
    	if(user != null) {
	        VaadinSession.getCurrent().setAttribute(User.class.getName(), user);
	        updateContent();
    	} else {
    		Notification.show("Login failed. Please enter valid username and password.", Notification.Type.ERROR_MESSAGE);
    	}
    }
    
    @Subscribe
    public void userLoggedOut(final UserLoggedOutEvent event) {
        // When the user logs out, current VaadinSession gets closed and the
        // page gets reloaded on the login screen. Do notice the this doesn't
        // invalidate the current HttpSession.
        VaadinSession.getCurrent().close();
        HibernateUtils.getSessionFactory().getCache().evictAllRegions();
        Page.getCurrent().reload();
    }
    
    public static DashboardEventBus getDashboardEventbus() {
        return ((MainUI) getCurrent()).dashboardEventbus;
    }
    
    public static Controller getController() {
        return ((MainUI) getCurrent()).controller;
    }
    
    @WebServlet(urlPatterns = "/*", name = "MainUIServlet", asyncSupported = true)
    @VaadinServletConfiguration(ui = MainUI.class, productionMode = false)
    public static class MainUIServlet extends VaadinServlet {
    }
}
