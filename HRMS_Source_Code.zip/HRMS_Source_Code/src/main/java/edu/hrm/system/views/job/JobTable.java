package edu.hrm.system.views.job;

import com.vaadin.data.util.IndexedContainer;
import com.vaadin.event.Action;
import com.vaadin.server.FontAwesome;
import com.vaadin.ui.Button;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Table;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.job.Job;
import edu.hrm.system.views.common.AbstractTable;
import edu.hrm.system.views.common.DeleteEntityWindow;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class JobTable extends AbstractTable implements IRefreshable {

	public JobTable() {
		super();
		setPageLength(10);
		// adding action column for edit and delete row
		addGeneratedColumn(Columns.ID.getColumnId(), new ColumnGenerator() {			
			@Override
			public Object generateCell(Table source, Object itemId, Object columnId) {
				HorizontalLayout actionLayout = new HorizontalLayout();
				actionLayout.setSpacing(true);
				// edit button
				Button editButton = new Button(FontAwesome.EDIT);
				editButton.addStyleName(ValoTheme.BUTTON_QUIET);
				editButton.addStyleName(ValoTheme.BUTTON_TINY);
				editButton.addClickListener(listener -> {
					Job job  = (Job)itemId;
					AddEditJobWindow.open("Edit job", job, JobTable.this);
				});
				// delete button
				Button deleteButton = new Button(FontAwesome.TRASH_O);
				deleteButton.addStyleName(ValoTheme.BUTTON_QUIET);
				deleteButton.addStyleName(ValoTheme.BUTTON_TINY);
				deleteButton.addClickListener(listener -> {
					Job job  = (Job)itemId;
					DeleteEntityWindow.open("Delete job", job, JobTable.this);
				});
				
				actionLayout.addComponent(editButton);
				actionLayout.addComponent(deleteButton);
				
				return actionLayout;
			}
		});
		// add item click listener
		addItemClickListener(listener -> {
			if(listener.isDoubleClick()) {
				Job job  = (Job)listener.getItemId();
				AddEditJobWindow.open("Edit job", job, JobTable.this);
			}
		});
	}

	@Override
	public void refresh() {
		createDataSource(MainUI.getController().getJobController().createContainer(MainUI.getController().getJobController().getAll()));
		refreshRowCache();
	}
	
	@Override
	public void handleAction(Action action, Object sender, Object target) {
		
	}

	@Override
	public void createDataSource(IndexedContainer container) {
		setContainerDataSource(container);
		setVisibleColumns(Columns.ID.getColumnId(), Columns.NAME.getColumnId(), Columns.DESCRIPTION.getColumnId(), Columns.ORGANIZATION.getColumnId());
		setColumnHeaders(Columns.ID.getColumnName(), Columns.NAME.getColumnName(), Columns.DESCRIPTION.getColumnName(), Columns.ORGANIZATION.getColumnId());
		setColumnWidth(Columns.ID.getColumnId(), 102);
	}

	
	public enum Columns {
		ID("jobId", "Action", Integer.class),
		NAME("name", "Job Name", String.class),
		DESCRIPTION("description", "Job Description", String.class),
		ORGANIZATION("organization", "Organization Name", String.class);

		private String columnId;
        private String columnName;
        private Class<?> valueType;

       Columns(String columnId, String columnName, Class<?> valueType) {
       	this.columnId = columnId;
           this.columnName = columnName;
           this.valueType = valueType;
       }
       
       public String getColumnId() {
			return columnId;
		}

       public String getColumnName() {
           return columnName;
       }

       public Class<?> getValueType() {
           return valueType;
       }
   }
}