package edu.hrm.system.views.user;

import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.user.job.AssignUserJobWindow;
import edu.hrm.system.views.user.profile.AddEditUserWindow;
import edu.hrm.system.views.user.profile.ResetPasswordWindow;

@SuppressWarnings("serial")
public class UserView extends VerticalLayout {

	private UserTable userTable = new UserTable();
	
	public UserView() {
		setSpacing(true);
		setCaption("Users");
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Overview of users");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);
		
		formLayout.addComponent(formLabel);	
		
		userTable.createDataSource(MainUI.getController().getUserController().createContainer(MainUI.getController().getUserController().getAll()));
		
		VerticalLayout tableLayout = new VerticalLayout();
		tableLayout.setMargin(true);
		tableLayout.setSpacing(true);
		
		Button addUserButton = new Button("Add user", listener -> {
			AddEditUserWindow.open("Add new user", null, userTable);
		});
		addUserButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
		
		Button resetPasswordButton = new Button("Reset password", listener -> {
			if(userTable.getValue() == null) {
				Notification.show("Please select user from table to reset password", Notification.Type.WARNING_MESSAGE);
				return;
			}
			ResetPasswordWindow.open((User)userTable.getValue());
		});
		
		Button assignUserToJobButton = new Button("Assign job to user", listener -> {
			
			if(userTable.getValue() == null) {
				Notification.show("Please select user from table to assign job", Notification.Type.WARNING_MESSAGE);
				return;
			}
			AssignUserJobWindow.open((User)userTable.getValue(), userTable);
			
		});
		assignUserToJobButton.addStyleName(ValoTheme.BUTTON_PRIMARY);

		HorizontalLayout actions = new HorizontalLayout(addUserButton, resetPasswordButton, assignUserToJobButton);
		actions.setSpacing(true);
		
		tableLayout.addComponent(actions);
		tableLayout.addComponent(userTable);
		
		addComponent(formLayout);
		addComponent(tableLayout);
	}

}
