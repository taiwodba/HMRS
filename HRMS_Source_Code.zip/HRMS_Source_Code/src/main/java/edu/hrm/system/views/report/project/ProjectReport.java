package edu.hrm.system.views.report.project;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.model.ChartType;
import com.vaadin.addon.charts.model.Cursor;
import com.vaadin.addon.charts.model.DataSeries;
import com.vaadin.addon.charts.model.DataSeriesItem;
import com.vaadin.addon.charts.model.Labels;
import com.vaadin.addon.charts.model.PlotOptionsBar;
import com.vaadin.addon.charts.model.PlotOptionsPie;
import com.vaadin.addon.charts.model.Series;
import com.vaadin.addon.charts.model.Title;
import com.vaadin.addon.charts.model.VerticalAlign;
import com.vaadin.addon.charts.model.YAxis;
import com.vaadin.ui.VerticalLayout;

import edu.hrm.system.MainUI;
import edu.hrm.system.models.report.ProjectHours;


@SuppressWarnings("serial")
public class ProjectReport extends VerticalLayout {
	
	private Chart barChart;
	private Chart pieChart;
	
	public ProjectReport() {
		setSizeFull();
		setMargin(true);
	}
	
	public void refresh(Date fromDate, Date toDate) {
		removeAllComponents();
		// create bar chart
		addComponent(barChart =  new Chart(ChartType.BAR));
		barChart.getConfiguration().setTitle("Projects working hours");
		
		List<ProjectHours> projectHours = MainUI.getController().getReportController().gerProjectsChartData(null, fromDate, toDate);
		
		List<Series> series = new ArrayList<>();
		
		for(ProjectHours projectHour : projectHours) {
			DataSeries serie = new DataSeries(projectHour.getProject().getName());
			serie.add(new DataSeriesItem(projectHour.getProject().getName(), projectHour.getTotalWorkingHours()));
			series.add(serie);
		}
		barChart.getConfiguration().setSeries(series);
		PlotOptionsBar plot = new PlotOptionsBar();
        plot.setDataLabels(new Labels(true));
        barChart.getConfiguration().setPlotOptions(plot);
        
        YAxis y = new YAxis();
        y.setMin(0);
        Title title = new Title("Working Hours");
        title.setVerticalAlign(VerticalAlign.HIGH);
        y.setTitle(title);
        barChart.getConfiguration().addyAxis(y);
		
		// create pie chart
		addComponent(pieChart =  new Chart(ChartType.PIE));
		pieChart.getConfiguration().setTitle("Projects working hours percentage");
		
		DataSeries pieSeries = new DataSeries();
		
		for(ProjectHours projectHour : projectHours) {
			pieSeries.add(new DataSeriesItem(projectHour.getProject().getName(), projectHour.getTotalWorkingHours()));
		}
		pieChart.getConfiguration().setSeries(pieSeries);
		
		PlotOptionsPie plotOptions = new PlotOptionsPie();
        plotOptions.setCursor(Cursor.POINTER);
        plotOptions.setShowInLegend(true);
        Labels dataLabels = new Labels();
        dataLabels.setEnabled(true);
        dataLabels.setFormatter("''+ this.point.name +': '+ Math.round(this.percentage) +' %'");
        plotOptions.setDataLabels(dataLabels);
        pieChart.getConfiguration().setPlotOptions(plotOptions);
	}
}
