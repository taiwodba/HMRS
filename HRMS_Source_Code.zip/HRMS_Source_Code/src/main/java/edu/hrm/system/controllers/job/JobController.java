package edu.hrm.system.controllers.job;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.vaadin.data.util.IndexedContainer;

import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.job.Job;
import edu.hrm.system.views.job.JobTable;

public class JobController {

	/*
	  * Insert or update Job
	  */
	public Job insertOrUpdate(Job job) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(job);
		hibernateTransaction.commit();
		session.close();
		return job;
	}
	
	/*
	 * Delete Job
	 */
	public void delete(Job job) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.delete(job);
		hibernateTransaction.commit();
		session.close();
	}
	
	/*
	 * Get all jobs from database
	 */
	@SuppressWarnings("unchecked")
	public List<Job> getAll() {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(Job.class);
		List<Job> jobs = (List<Job>)criteria.list();
		session.close();
		return jobs;
	}

	/*
     * Creating Job container
     */
    @SuppressWarnings("unchecked")
	public IndexedContainer createContainer(List<Job> jobs) {
		IndexedContainer container = new IndexedContainer();
		// creating properties
		for(JobTable.Columns property : JobTable.Columns.values()) {
			container.addContainerProperty(property.getColumnId(), property.getValueType(), null);
		}
		for(Job job : jobs) {
			container.addItem(job);
			
			container.getContainerProperty(job, JobTable.Columns.NAME.getColumnId()).setValue(job.getName());
			container.getContainerProperty(job, JobTable.Columns.DESCRIPTION.getColumnId()).setValue(job.getDescription());
			container.getContainerProperty(job, JobTable.Columns.ORGANIZATION.getColumnId()).setValue(job.getOrganization().getName());
		}
		return container;
	}
    
    

}
