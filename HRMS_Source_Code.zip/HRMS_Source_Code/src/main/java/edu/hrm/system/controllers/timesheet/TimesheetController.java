package edu.hrm.system.controllers.timesheet;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.CacheMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.vaadin.ui.Notification;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.activity.Activity;
import edu.hrm.system.models.project.Project;
import edu.hrm.system.models.timesheet.Timesheet;
import edu.hrm.system.models.timesheet.TimesheetStatus;
import edu.hrm.system.models.timesheet.Timesheetitem;
import edu.hrm.system.models.user.User;


public class TimesheetController {

	/*
	 * Insert or update Timesheet
	 */
	public Timesheet insertOrUpdateTimesheet(Timesheet timesheet) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(timesheet);
		hibernateTransaction.commit();
		session.close();
		return timesheet;
	}
	
	/*
	 * Insert or update user
	 */
	public Timesheetitem insertOrUpdateTimesheetItem(Timesheetitem timesheetitem) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(timesheetitem);
		hibernateTransaction.commit();
		session.close();
		return timesheetitem;
	}
	
	public Timesheet createTimesheet(Date date) {
		// get monday and sunday of the week
		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		Date startDate = calendar.getTime();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		Date endDate = calendar.getTime();
		if(getTimesheet(startDate, endDate) != null) {
			Notification.show("Timesheet for the week "+startDate.toString()+" - "+endDate.toString()+" is already created", Notification.Type.WARNING_MESSAGE);
			return null;
		}
		
		// creating new timesheet
		Timesheet timesheet = new Timesheet();
		timesheet.setActive(true);
		timesheet.setStatus(TimesheetStatus.CREATED.toString());
		timesheet.setStartDate(startDate);
		timesheet.setEndDate(endDate);
		timesheet.setWeek("W"+calendar.get(Calendar.WEEK_OF_YEAR));
		timesheet.setUser(Controller.getCurrentUser());
		timesheet.setCreatedAt(new Date());
		insertOrUpdateTimesheet(timesheet);
		
		Calendar start = Calendar.getInstance();
		start.setTime(startDate);
		Calendar end = Calendar.getInstance();
		end.setTime(endDate);
		end.add(Calendar.DATE, 1);

		for (Date day = start.getTime(); start.before(end); start.add(Calendar.DATE, 1), day = start.getTime()) {
		   Timesheetitem timesheetitem = new Timesheetitem();
		   timesheetitem.setDay(day);
		   timesheetitem.setWorkHours(BigDecimal.ZERO);
		   timesheetitem.setTimesheet(timesheet);
		   insertOrUpdateTimesheetItem(timesheetitem);
		   timesheet.getTimesheetitems().add(timesheetitem);
		}
		return timesheet;
	}
	/*
	 * Get timesheet from database based on startDate and endDate
	 */
	public Timesheet getTimesheet(Timesheet timesheet, Project project, Activity activity) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Query query = session.createQuery("from edu.hrm.system.models.timesheet.Timesheet timesheet where timesheet.timesheetId <> :timesheetId and timesheet.activity = :activity and timesheet.project = :project and timesheet.active = true and timesheet.startDate = :startDate and timesheet.endDate = :endDate and timesheet.user = :user");	
		query.setCacheable(false);
		query.setCacheMode(CacheMode.IGNORE);
		query.setParameter("timesheetId", timesheet.getTimesheetId());
		query.setParameter("startDate", timesheet.getStartDate());
		query.setParameter("endDate", timesheet.getEndDate());
		query.setParameter("user", Controller.getCurrentUser());
		query.setParameter("project", project);
		query.setParameter("activity", activity);
		Timesheet oldTimesheet = (Timesheet)query.uniqueResult();
		session.close();
		return oldTimesheet;
	}
	/*
	 * Get timesheet from database based on startDate and endDate
	 */
	public Timesheet getTimesheet(Date startDate, Date endDate) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Query query = session.createQuery("from edu.hrm.system.models.timesheet.Timesheet timesheet where timesheet.activity is null and timesheet.project is null and timesheet.active = true and timesheet.startDate = :startDate and timesheet.endDate = :endDate and timesheet.user = :user");	
		query.setCacheable(false);
		query.setCacheMode(CacheMode.IGNORE);
		query.setParameter("startDate", startDate);
		query.setParameter("endDate", endDate);
		query.setParameter("user", Controller.getCurrentUser());
		Timesheet timesheet = (Timesheet)query.uniqueResult();
		session.close();
		return timesheet;
	}
	
	/*
	 * get timesheets for date
	 */
	@SuppressWarnings("unchecked")
	public List<Timesheet> getTimesheets(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Session session = HibernateUtils.getSessionFactory().openSession();
		String queryString = "from edu.hrm.system.models.timesheet.Timesheet timesheet where timesheet.active = true and timesheet.user = :user ";
		if(date == null) {
			queryString += "and timesheet.startDate <= '"+dateFormat.format(new Date())+"'";
		} else {
			queryString += "and timesheet.startDate <= '"+dateFormat.format(date)+"' and timesheet.endDate >= '"+dateFormat.format(date)+"'";
		}
		Query query = session.createQuery(queryString);	
		query.setCacheable(false);
		query.setCacheMode(CacheMode.IGNORE);
		query.setParameter("user", Controller.getCurrentUser());
		List<Timesheet> timesheets = (List<Timesheet>)query.list();
		session.close();
		return timesheets;
	}
	
	/*
	 * get timesheets for date
	 */
	@SuppressWarnings("unchecked")
	public List<Timesheet> getTimesheets(User user, Date fromDate, Date toDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Session session = HibernateUtils.getSessionFactory().openSession();
		String queryString = "from edu.hrm.system.models.timesheet.Timesheet timesheet where timesheet.approved = true and timesheet.active = true and  timesheet.project is not null ";
		queryString += "and timesheet.createdAt >= '"+dateFormat.format(fromDate)+"' and timesheet.createdAt <= '"+dateFormat.format(toDate)+"'";
		
		if(user != null) {
			queryString +=" and timesheet.user = :user";
		}
		Query query = session.createQuery(queryString);	
		if(user != null) {
			query.setParameter("user", user);
		}
		query.setCacheable(false);
		query.setCacheMode(CacheMode.IGNORE);
		List<Timesheet> timesheets = (List<Timesheet>)query.list();
		session.close();
		return timesheets;
	}
	
	/*
	 * get timesheets for date
	 */
	@SuppressWarnings("unchecked")
	public List<Timesheetitem> getTimesheetItems(User user, Date fromDate, Date toDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Session session = HibernateUtils.getSessionFactory().openSession();
		String queryString = "from edu.hrm.system.models.timesheet.Timesheetitem timesheetitem where timesheetitem.timesheet.approved = true and timesheetitem.timesheet.active = true and  timesheetitem.timesheet.project is not null ";
		queryString += "and timesheetitem.day >= '"+dateFormat.format(fromDate)+"' and timesheetitem.day <= '"+dateFormat.format(toDate)+"'";
		
		if(user != null) {
			queryString +=" and timesheetitem.timesheet.user = :user";
		}
		Query query = session.createQuery(queryString);	
		if(user != null) {
			query.setParameter("user", user);
		}
		query.setCacheable(false);
		query.setCacheMode(CacheMode.IGNORE);
		List<Timesheetitem> timesheetitems = (List<Timesheetitem>)query.list();
		session.close();
		return timesheetitems;
	}
	
	@SuppressWarnings("unchecked")
	public List<Timesheet> getAdminTimesheets(Date date, User user) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Session session = HibernateUtils.getSessionFactory().openSession();
		String queryString = "from edu.hrm.system.models.timesheet.Timesheet timesheet where timesheet.active = true and timesheet.status != 'CREATED' and timesheet.status != 'REJECTED' and timesheet.user = :user ";
		if(date == null) {
			queryString += "and timesheet.startDate <= '"+dateFormat.format(new Date())+"'";
		} else {
			queryString += "and timesheet.startDate <= '"+dateFormat.format(date)+"' and timesheet.endDate >= '"+dateFormat.format(date)+"'";
		}
		queryString += " order by timesheet.startDate desc";
		Query query = session.createQuery(queryString);	
		query.setCacheable(false);
		query.setCacheMode(CacheMode.IGNORE);
		query.setParameter("user", user);
		List<Timesheet> timesheets = (List<Timesheet>)query.list();
		session.close();
		return timesheets;
	}
	
	
	/*
	 * Delete timesheet
	 */
	public void delete(Timesheet timesheet) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.delete(timesheet);
		hibernateTransaction.commit();
		session.close();
	}

	
	
}
