package edu.hrm.system.views.common;

import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.ui.Window;

@SuppressWarnings("serial")
public abstract class BasicWindow extends Window {
	
	public BasicWindow(String caption) {
		setCaption(caption);
		center();
		setModal(true);
        setCloseShortcut(KeyCode.ESCAPE, null);
        setResizable(true);
        setClosable(true);
        setCaption(caption);
        addStyleName("no-vertical-drag-hints");
        addStyleName("no-horizontal-drag-hints");
	}

}
