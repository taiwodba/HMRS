package edu.hrm.system.views.leave.calendar;

import java.util.Date;

import com.vaadin.ui.components.calendar.event.CalendarEvent;


@SuppressWarnings("serial")
public class LeaveCalendarEvent implements CalendarEvent {

	private Date start;
	private Date end;
	private String caption;
	private String description;
	private String styleName;
	private boolean allDay;
	
	public LeaveCalendarEvent(Date start, Date end, String caption, String description) {
		this(start, end, caption, description, "color1", true);
	}
	
	public LeaveCalendarEvent(Date start, Date end, String caption, String description, String styleName, boolean allDay) {
		this.start = start;
		this.end = end;
		this.caption = caption;
		this.description = description;
		this.styleName = styleName;
		this.allDay = allDay;
	}

	@Override
	public Date getStart() {
		return start;
	}

	@Override
	public Date getEnd() {
		return end;
	}

	@Override
	public String getCaption() {
		return caption;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getStyleName() {
		return styleName;
	}

	@Override
	public boolean isAllDay() {
		return allDay;
	}

}
