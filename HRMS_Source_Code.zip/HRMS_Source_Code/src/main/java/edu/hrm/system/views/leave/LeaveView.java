package edu.hrm.system.views.leave;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.views.leave.balance.LeaveBalanceTab;

@SuppressWarnings("serial")
public class LeaveView extends TabSheet implements View {

	public LeaveView() {
		setSizeFull();
		addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);
		DashboardEventBus.register(this);
	}
	
	@Override
	public void enter(ViewChangeEvent event) {
		removeAllComponents();
		
		
		// second tab leave balance
		if(Controller.getCurrentUser().isManager()) {
			addTab(new LeaveBalanceTab());
		} else {
			// first tab apply leave view
			addTab(new ApplyLeaveTab());
		}
		
	}

}
