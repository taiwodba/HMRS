package edu.hrm.system.models.report;

import java.math.BigDecimal;

import edu.hrm.system.models.project.Project;

public class ProjectHours {

	private Project project;
	private BigDecimal totalWorkingHours;
	
	public ProjectHours(Project project) {
		this.project = project;
		this.totalWorkingHours = BigDecimal.ZERO;
	}

	public Project getProject() {
		return project;
	}
	
	public void setProject(Project project) {
		this.project = project;
	}
	
	public void addHours(BigDecimal hours) {
		this.totalWorkingHours = this.totalWorkingHours.add(hours);
	}
	
	public BigDecimal getTotalWorkingHours() {
		return totalWorkingHours;
	}
	
	public void setTotalWorkingHours(BigDecimal totalWorkingHours) {
		this.totalWorkingHours = totalWorkingHours;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((project == null) ? 0 : project.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProjectHours other = (ProjectHours) obj;
		if (project == null) {
			if (other.project != null)
				return false;
		} else if (!project.equals(other.project))
			return false;
		return true;
	}
}
