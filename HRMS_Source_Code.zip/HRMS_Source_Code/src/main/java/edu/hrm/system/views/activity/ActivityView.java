package edu.hrm.system.views.activity;

import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;


@SuppressWarnings("serial")
public class ActivityView extends VerticalLayout  {

	private ActivityTable activityTable = new ActivityTable();
	
	public ActivityView() {
		// activity layout
		Label activityLabel = new Label("Overview of activities");
		activityLabel.addStyleName(ValoTheme.LABEL_COLORED);
		activityLabel.addStyleName(ValoTheme.LABEL_H3);
		FormLayout activityFormLayout = new FormLayout();
		activityFormLayout.setMargin(true);
		activityFormLayout.setSpacing(true);
		activityFormLayout.addComponent(activityLabel);
		
		VerticalLayout tableLayout = new VerticalLayout();
		tableLayout.setMargin(true);
		tableLayout.setSpacing(true);
		
		Button addActivityButton = new Button("Add activity", listener -> {
			AddEditActivityWindow.open("Add new activity", null, activityTable);
		});
		addActivityButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);

		tableLayout.addComponent(addActivityButton);
		tableLayout.addComponent(activityTable);
		
		addComponent(tableLayout);
		addComponent(activityFormLayout);
	}
	
	public ActivityTable getActivityTable() {
		return activityTable;
	}
}
