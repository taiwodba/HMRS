package edu.hrm.system.controllers;


import com.vaadin.server.VaadinSession;

import edu.hrm.system.controllers.activity.ActivityController;
import edu.hrm.system.controllers.job.JobController;
import edu.hrm.system.controllers.leave.LeaveController;
import edu.hrm.system.controllers.organization.OrganizationController;
import edu.hrm.system.controllers.project.ProjectController;
import edu.hrm.system.controllers.report.ReportController;
import edu.hrm.system.controllers.timesheet.TimesheetController;
import edu.hrm.system.controllers.user.UserController;
import edu.hrm.system.models.user.User;

public class Controller {

	private UserController userController;
	private OrganizationController organizationController;
	private JobController jobController;
	private ProjectController projectController;
	private ActivityController activityController;
	private TimesheetController timesheetController;
	private LeaveController leaveController;
	private ReportController reportController;
	public static User user;
	
	public void initUserController() {
		this.userController = new UserController();
	}
	
	public void initOrganizationController() {
		this.organizationController = new OrganizationController();
	}
	
	public void initJobController() {
		this.jobController = new JobController();
	}
	
	public void initProjectController() {
		this.projectController = new ProjectController();
	}

	public void initActivityController() {
		this.activityController = new ActivityController();
	}
	
	public void initTimesheetController() {
		this.timesheetController = new TimesheetController();
	}
	
	public void initLeaveController() {
		this.leaveController = new LeaveController();
	}
	
	public UserController getUserController() {
		return userController;
	}
	
	public OrganizationController getOrganizationController() {
		return organizationController;
	}
	
	public JobController getJobController() {
		return jobController;
	}
	
	public ProjectController getProjectController() {
		return projectController;
	}
	
	public ActivityController getActivityController() {
		return activityController;
	}
	
	public TimesheetController getTimesheetController() {
		return timesheetController;
	}
	
	public LeaveController getLeaveController() {
		return leaveController;
	}
	
	private void initReportController() {
		this.reportController = new ReportController();
	}
	
	public ReportController getReportController() {
		return reportController;
	}
	
	
	public void init() {
		initUserController();
    	initOrganizationController();
    	initJobController();
    	initProjectController();
    	initActivityController();
    	initTimesheetController();
    	initLeaveController();
    	initReportController();
	}
	
	/*
	 * get user from session
	 */
	public static User getCurrentUser() {
		if(VaadinSession.getCurrent()!=null) {
			return (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
		} else {
			return user;
		}
    }
}
