package edu.hrm.system.views.leave;

import java.util.ArrayList;
import java.util.List;

import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.controllers.Controller;
import edu.hrm.system.models.leave.Leave;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.EntitySelectField;
@SuppressWarnings("serial")
public class MyLeavesTab extends VerticalLayout {

	private MyLeavesTable leavesTable = new MyLeavesTable();
	private EntitySelectField<User> userSelect;
	
	public MyLeavesTab() {
		setSpacing(true);
		setCaption("My Leaves");
		
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("My Leaves");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);

		formLayout.addComponent(formLabel);
		
		VerticalLayout tableLayout = new VerticalLayout();
		tableLayout.setMargin(true);
		tableLayout.setSpacing(true);
		List<Leave> leaves = new ArrayList<>();
	
		if(Controller.getCurrentUser().isManager()) { 
			leaves = MainUI.getController().getLeaveController().getMyLeaves(null);
			
			userSelect = new EntitySelectField<User>(null, User.class);
			userSelect.addItems(MainUI.getController().getUserController().getIndividualUsers());
			tableLayout.addComponent(userSelect);
			userSelect.addValueChangeListener(listener -> {
				leavesTable.setUser(userSelect.getSelectedValue());
				leavesTable.refresh();
			});
		} else {
			leaves = MainUI.getController().getLeaveController().getMyLeaves(Controller.getCurrentUser());
		}
		leavesTable.createDataSource(MainUI.getController().getLeaveController().createContainer(leaves));
		
		tableLayout.addComponent(leavesTable);
		
		addComponent(formLayout);
		addComponent(tableLayout);
	}

}