package edu.hrm.system.views.admin;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.views.job.JobView;
import edu.hrm.system.views.organization.OrganizationView;
import edu.hrm.system.views.project.ProjectView;
import edu.hrm.system.views.user.UserView;

@SuppressWarnings("serial")
public class AdminView extends TabSheet implements View {

	public AdminView() {
		setSizeFull();
		addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);
		DashboardEventBus.register(this);
	}
	
	@Override
	public void enter(ViewChangeEvent event) {
		removeAllComponents();
		// check permissions
		if(!Controller.getCurrentUser().isAdmin()) {
			Notification.show("You don't have permission to view this url.", Notification.Type.ERROR_MESSAGE);
			return;
		}
		// first tab user view
		addTab(new UserView());
		// second tab organization 
		addTab(new OrganizationView());
		// third tab organization 
		addTab(new JobView());
		// fourth tab organization 
		addTab(new ProjectView());
	}

}
