package edu.hrm.system.views.report.project;

import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class ProjectReportTab extends VerticalLayout  {

	private ProjectReport projectReport = new ProjectReport();
	
	public ProjectReportTab() {
		setSpacing(true);
		setCaption("Project Report");
		FormLayout formLayout = new FormLayout();
		formLayout.setMargin(true);
		formLayout.setSpacing(true);
		Label formLabel = new Label("Report Work On a Project");
		formLabel.addStyleName(ValoTheme.LABEL_COLORED);
		formLabel.addStyleName(ValoTheme.LABEL_H3);
		
		formLayout.addComponent(formLabel);	
		
		DateField fromDate = new DateField("From Date");
		DateField toDate = new DateField("To Date");
		
		Button filterButton = new Button("Filter", listener -> {
			projectReport.refresh(fromDate.getValue(), toDate.getValue());
		});
		filterButton.addStyleName(ValoTheme.BUTTON_PRIMARY);
		formLayout.addComponents(fromDate, toDate, filterButton);
		
		addComponent(formLayout);
		addComponent(projectReport);
	}
}
