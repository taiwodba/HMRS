package edu.hrm.system.views.leave.calendar;

import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

@SuppressWarnings("serial")
public class MyCalendarTab extends VerticalLayout  {

	private final CalendarMonthYearComponent monthSelectComponent;
	private CalendarComponent calendarComponent;
	
	public MyCalendarTab() {
		setSpacing(true);
		setCaption("My Calendar");
		
		addComponent(monthSelectComponent = new CalendarMonthYearComponent());
		monthSelectComponent.getPreviousMonthButton().addClickListener(addButtonClickListener(-1));
		monthSelectComponent.getNextMonthButton().addClickListener(addButtonClickListener(1));
		monthSelectComponent.getMonthYearDateField().addValueChangeListener(addValueChangeListener());
		calendarComponent = new CalendarComponent();
		calendarComponent.refresh(new Date(), DateUtils.addMonths(new Date(), 1), true);
		addComponent(calendarComponent);
	}
	
	private ClickListener addButtonClickListener(final int relativeValue) {
		return new ClickListener() {
			@Override
			public void buttonClick(ClickEvent event) {
				calendarComponent.refresh(DateUtils.addMonths(calendarComponent.getStartDate(), relativeValue), DateUtils.addMonths(calendarComponent.getEndDate(), relativeValue), false);
				monthSelectComponent.getMonthYearDateField().setValue(calendarComponent.getStartDate());
			}
		};
	}

	private ValueChangeListener addValueChangeListener() {
		return new ValueChangeListener() {

			@Override
			public void valueChange(ValueChangeEvent event) {
				Date selectedDate = monthSelectComponent.getMonthYearDateField().getValue();
				calendarComponent.refresh(selectedDate, DateUtils.addMonths(selectedDate, 1), false);
			}
		};
	}
}
