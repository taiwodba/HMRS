package edu.hrm.system.models.timesheet;

public enum TimesheetStatus {
	CREATED,
	PENDING,
	APPROVED,
	REJECTED
}
