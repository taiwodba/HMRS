package edu.hrm.system.views.user.job;

import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.job.Job;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.common.BasicWindow;
import edu.hrm.system.views.common.EntitySelectField;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class AssignUserJobWindow extends BasicWindow {

    public static final String ID = "assignuserjobwindow";

    private AssignUserJobWindow(User user, IRefreshable refreshable) {
        super("Assign user to job");
        setId(ID);
        setWidth("400px");
        Responsive.makeResponsive(this);

        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        formLayout.setSpacing(true);
        
        Label usernameLabel = new Label(user.getUsername());
        usernameLabel.setCaption("Username");
        formLayout.addComponent(usernameLabel);
        
        EntitySelectField<Job> jobSelectField = new EntitySelectField<Job>("Job", Job.class);
        formLayout.addComponent(jobSelectField);

        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Save", listener -> {
        	MainUI.getController().getUserController().assignJobToUser(jobSelectField.getSelectedValue(), user);
        	Notification.show("Job assigned to user", Notification.Type.TRAY_NOTIFICATION);
        	refreshable.refresh();
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        buttons.addComponent(closeButton);
      
        formLayout.addComponent(buttons);
        setContent(formLayout);

    }


    public static void open(User user, IRefreshable refreshable) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new AssignUserJobWindow(user, refreshable);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}