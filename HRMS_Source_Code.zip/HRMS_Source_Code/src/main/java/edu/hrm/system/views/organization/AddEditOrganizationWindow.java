package edu.hrm.system.views.organization;

import org.apache.commons.lang3.StringUtils;

import com.vaadin.server.Responsive;
import com.vaadin.ui.Button;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

import edu.hrm.system.MainUI;
import edu.hrm.system.events.DashboardEventBus;
import edu.hrm.system.events.DashboardEvent.CloseOpenWindowsEvent;
import edu.hrm.system.models.organization.Organization;
import edu.hrm.system.views.common.BasicWindow;
import edu.hrm.system.views.common.IRefreshable;

@SuppressWarnings("serial")
public class AddEditOrganizationWindow extends BasicWindow {

    public static final String ID = "addeditorganization";
    private Organization organization;
    
	public AddEditOrganizationWindow(String caption, Organization organization, IRefreshable refresher) {
		super(caption);
		this.organization = organization;
		setId(ID);
        setWidth("500px");
        Responsive.makeResponsive(this);
       
        FormLayout formLayout = new FormLayout();
        formLayout.setMargin(true);
        
        Label section = new Label("Organization Info");
        section.addStyleName("h2");
        section.addStyleName("colored");
        formLayout.addComponent(section);
        // organization info
        TextField nameField = new TextField("Organization Name");
        nameField.setRequired(true);
        nameField.setRequiredError("Organization Name is required");
        
        TextArea descriptionField = new TextArea("Organization Description");
        descriptionField.setHeight("100px");
        
        formLayout.addComponents(nameField, descriptionField);
        
        
        if(this.organization != null) {
        	nameField.setValue(this.organization.getName());
        	descriptionField.setValue(StringUtils.defaultIfEmpty(this.organization.getDescription(),""));
        }
        
        HorizontalLayout buttons = new HorizontalLayout();
        buttons.setMargin(true);
        buttons.setSpacing(true);
        
        Button saveButton = new Button("Save", listener -> {
        	// validate user input
        	if(!nameField.isValid() || !descriptionField.isValid()) {
        		Notification.show("Please enter valid form data.", Notification.Type.WARNING_MESSAGE);
        		return;
        	}
        	// send user to controller for saving
        	if(this.organization == null) {
        		this.organization = new Organization();
        	}
        	
        	this.organization.setName(nameField.getValue());
        	this.organization.setDescription(descriptionField.getValue());
        	
        	MainUI.getController().getOrganizationController().insertOrUpdate(this.organization);
        	
        	Notification.show("Successfully update organization", Notification.Type.TRAY_NOTIFICATION);
        	refresher.refresh();
        	close();
        });
        saveButton.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        buttons.addComponent(saveButton);
        
        Button closeButton = new Button("Close", listener -> {
        	close();
        });
        buttons.addComponent(closeButton);
        formLayout.addComponent(buttons);
        setContent(formLayout);
	}

	public static void open(String caption, Organization organization, IRefreshable refresher) {
        DashboardEventBus.post(new CloseOpenWindowsEvent());
        Window window = new AddEditOrganizationWindow(caption, organization, refresher);
        UI.getCurrent().addWindow(window);
        window.focus();
    }
}
