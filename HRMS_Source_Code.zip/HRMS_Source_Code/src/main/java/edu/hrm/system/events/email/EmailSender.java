package edu.hrm.system.events.email;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailSender {

	private static final Logger LOGGER = Logger.getLogger(EmailSender.class.getName());
	private static final String EMAIL_CONFIGURATION_RESOURCE_PATH = "/email/";
	private static final String EMAIL_CONFIGURATION = "email_config.txt";

	private final EmailConfiguration emailConfiguration = new EmailConfiguration();

	public void send(String emailTo, String subject, String bodyMessage) {

		readConfigurationParameters();

		Session session = Session.getDefaultInstance(new UserEmailProperties(emailConfiguration), new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(emailConfiguration.getUserId(), emailConfiguration.getEmailFromPassword());
			}
		});

		Message message = new MimeMessage(session);

		try {
			message.setFrom(new InternetAddress(emailConfiguration.getEmailFrom()));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailTo));
			message.setSubject(subject);
			message.setContent(bodyMessage, "text/html");
			Transport.send(message);
		}
		catch (MessagingException e) {
			LOGGER.log(Level.SEVERE, e.getLocalizedMessage(), e);
		}
	}

	private void readConfigurationParameters() {
		String filename = EMAIL_CONFIGURATION; 
		try {
			InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(EMAIL_CONFIGURATION_RESOURCE_PATH + filename);
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			String line = null;
			while ((line = bufferedReader.readLine()) != null) {
				String[] keyValue = line.split("=");
				emailConfiguration.getClass().getDeclaredField(keyValue[0]).set(emailConfiguration, keyValue[1]);
			}
			bufferedReader.close();
		}
		catch (IOException | SecurityException | IllegalAccessException | IllegalArgumentException | NoSuchFieldException e) {
			LOGGER.log(Level.SEVERE, e.getLocalizedMessage(), e);
		}
	}
}