package edu.hrm.system.controllers.user;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.vaadin.data.util.IndexedContainer;

import edu.hrm.system.controllers.Controller;
import edu.hrm.system.hibernate.HibernateUtils;
import edu.hrm.system.models.job.Job;
import edu.hrm.system.models.user.User;
import edu.hrm.system.views.user.UserTable;

public class UserController {
	
	/*
	 * Insert or update user
	 */
	public User insertOrUpdate(User user) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.saveOrUpdate(user);
		hibernateTransaction.commit();
		session.close();
		return user;
	}
	
	/*
	 * Delete user
	 */
	public User delete(User user) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction hibernateTransaction = session.beginTransaction();
		session.delete(user);
		hibernateTransaction.commit();
		session.close();
		return user;
	}
	
	/*
	 * Method to authenticate user based on username and password
	 */
	public User authenticate(String userName, String password) {
		String hashedPassword = md5Hash(password);
		return getUser(userName, hashedPassword);
	}

	/*
	 * Get user from database based on username and hashed password
	 */
	private User getUser(String userName, String hashedPassword) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Query query = session.createQuery("from edu.hrm.system.models.user.User user where user.enabled = true and user.username = :username and user.password = :password");	
		query.setParameter("username", userName);
		query.setParameter("password", hashedPassword);
		User user = (User)query.uniqueResult();
		session.close();
		return user;
	}
	
	/*
	 * Get all users from database
	 */
	@SuppressWarnings("unchecked")
	public List<User> getAll() {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(User.class);
		List<User> users = (List<User>)criteria.list();
		session.close();
		return users;
	}
	
	/*
	 * Get individual users
	 */
	@SuppressWarnings("unchecked")
	public List<User> getIndividualUsers() {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Query query = session.createQuery("from edu.hrm.system.models.user.User user where user.enabled = true and user.admin = false");	
		List<User> users = (List<User>)query.list();
		session.close();
		return users;
	}
	
	/*
	 * Get employee users
	 */
	@SuppressWarnings("unchecked")
	public List<User> getEmployeeUsers() {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Query query = session.createQuery("from edu.hrm.system.models.user.User user where user.enabled = true and user.manager = :manager");	
		query.setParameter("manager", Controller.getCurrentUser());
		List<User> users = (List<User>)query.list();
		session.close();
		return users;
	}
	
	
	/*
	 * Get posibble managers
	 */
	@SuppressWarnings("unchecked")
	public List<User> getManagerUsers() {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Query query = session.createQuery("from edu.hrm.system.models.user.User user where user.enabled = true and user.manager is null");	
		List<User> users = (List<User>)query.list();
		session.close();
		return users;
	}
	
	/*
	 * Assign job to user
	 */
	public void assignJobToUser(Job job, User user) {
		user.setJob(job);
		insertOrUpdate(user);
	}
	
    
    /*
     * Creating user container
     */
    @SuppressWarnings("unchecked")
	public IndexedContainer createContainer(List<User> users) {
		IndexedContainer container = new IndexedContainer();
		// creating properties
		for(UserTable.Columns property : UserTable.Columns.values()) {
			container.addContainerProperty(property.getColumnId(), property.getValueType(), null);
		}
		for(User user : users) {
			container.addItem(user);
			
			container.getContainerProperty(user, UserTable.Columns.USERNAME.getColumnId()).setValue(user.getUsername());
			container.getContainerProperty(user, UserTable.Columns.FIRST_NAME.getColumnId()).setValue(user.getFirstName());
			container.getContainerProperty(user, UserTable.Columns.LAST_NAME.getColumnId()).setValue(user.getLastName());
			container.getContainerProperty(user, UserTable.Columns.EMAIL.getColumnId()).setValue(user.getEmail());
			container.getContainerProperty(user, UserTable.Columns.MANAGER.getColumnId()).setValue(user.getManager()==null?"":user.getManager().toString());
			container.getContainerProperty(user, UserTable.Columns.JOB.getColumnId()).setValue(user.getJob()==null?"":user.getJob().toString());
			
			String enabled = "Enabled";
			if(!user.isEnabled()) {
				enabled = "Disabled";
			}
			container.getContainerProperty(user, UserTable.Columns.ENABLED.getColumnId()).setValue(enabled);
			
			String userRole = "Individual User";
			if(user.isAdmin()) {
				userRole = "Admin";
			}
			container.getContainerProperty(user, UserTable.Columns.ADMIN.getColumnId()).setValue(userRole);
		}
		return container;
	}
    
    /*
	 * Takes a string, and converts it to md5 hashed string
	 */
    public static String md5Hash(String message) {
        String md5 = "";
        if(null == message) 
            return null;
         
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");//Create MessageDigest object for MD5
            digest.update(message.getBytes(), 0, message.length());//Update input string in message digest
            md5 = new BigInteger(1, digest.digest()).toString(16);//Converts message digest value in base 16 (hex)
  
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return md5;
    }	
}
