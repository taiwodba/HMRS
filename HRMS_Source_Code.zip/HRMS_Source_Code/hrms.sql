-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 27, 2015 at 07:40 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hrms`
--
CREATE DATABASE IF NOT EXISTS `hrms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hrms`;

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE IF NOT EXISTS `activity` (
  `ActivityId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `ProjectId` int(11) NOT NULL,
  PRIMARY KEY (`ActivityId`),
  KEY `ProjectId` (`ProjectId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`ActivityId`, `Name`, `ProjectId`) VALUES
(1, 'QA Testing', 1),
(2, 'Testing', 2),
(3, 'Design', 1),
(4, 'Integration', 2);

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `JobId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Description` text,
  `OrganizationId` int(11) NOT NULL,
  PRIMARY KEY (`JobId`),
  KEY `OrganizationId` (`OrganizationId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`JobId`, `Name`, `Description`, `OrganizationId`) VALUES
(2, 'Test', '', 1),
(3, 'My new job', '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `leave`
--

CREATE TABLE IF NOT EXISTS `leave` (
  `LeaveId` int(11) NOT NULL AUTO_INCREMENT,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `WorkingDays` int(11) NOT NULL,
  `LeaveTypeId` int(11) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Comment` varchar(100) NOT NULL,
  `UserId` int(11) NOT NULL,
  PRIMARY KEY (`LeaveId`),
  UNIQUE KEY `FromDate` (`FromDate`,`ToDate`,`LeaveTypeId`),
  KEY `LeaveTypeId` (`LeaveTypeId`),
  KEY `UserId` (`UserId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `leave`
--


-- --------------------------------------------------------

--
-- Table structure for table `leavebalance`
--

CREATE TABLE IF NOT EXISTS `leavebalance` (
  `LeaveBalanceId` int(11) NOT NULL AUTO_INCREMENT,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `WorkingDays` int(11) NOT NULL,
  `LeaveTypeId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  PRIMARY KEY (`LeaveBalanceId`),
  KEY `UserId` (`UserId`),
  KEY `LeaveTypeId` (`LeaveTypeId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `leavebalance`
--

INSERT INTO `leavebalance` (`LeaveBalanceId`, `FromDate`, `ToDate`, `WorkingDays`, `LeaveTypeId`, `UserId`) VALUES
(1, '2015-01-01', '2015-06-15', 12, 1, 2),
(2, '2015-06-15', '2015-12-31', 12, 1, 2),
(3, '2015-01-01', '2015-12-31', 5, 2, 2),
(4, '2014-07-01', '2016-07-01', 15, 1, 3),
(5, '2015-07-20', '2015-07-22', 3, 2, 3),
(6, '2014-06-01', '2016-07-01', 10, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `leavetype`
--

CREATE TABLE IF NOT EXISTS `leavetype` (
  `LeaveTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(10) NOT NULL,
  PRIMARY KEY (`LeaveTypeId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `leavetype`
--

INSERT INTO `leavetype` (`LeaveTypeId`, `Name`) VALUES
(1, 'Vacation'),
(2, 'FMLA');

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE IF NOT EXISTS `organization` (
  `OrganizationId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Description` text,
  PRIMARY KEY (`OrganizationId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`OrganizationId`, `Name`, `Description`) VALUES
(1, 'Organization 1', 'Organization desciption'),
(2, 'Name', ''),
(3, 'New Organization', '');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `ProjectId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Description` text,
  `ProjectAdmin` int(11) DEFAULT NULL,
  PRIMARY KEY (`ProjectId`),
  KEY `ProjectAdmin` (`ProjectAdmin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`ProjectId`, `Name`, `Description`, `ProjectAdmin`) VALUES
(1, 'Oracle development', '', 1),
(2, 'Database migration', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `timesheet`
--

CREATE TABLE IF NOT EXISTS `timesheet` (
  `TimesheetId` int(11) NOT NULL AUTO_INCREMENT,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Week` varchar(5) NOT NULL,
  `UserId` int(11) NOT NULL,
  `ProjectId` int(11) DEFAULT NULL,
  `ActivityId` int(11) DEFAULT NULL,
  `Status` varchar(10) NOT NULL,
  `Active` tinyint(1) NOT NULL DEFAULT '1',
  `Approved` tinyint(1) NOT NULL DEFAULT '0',
  `CreatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`TimesheetId`),
  KEY `ProjectId` (`ProjectId`),
  KEY `UserId` (`UserId`),
  KEY `ActivityId` (`ActivityId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

--
-- Dumping data for table `timesheet`
--



-- --------------------------------------------------------

--
-- Table structure for table `timesheetitem`
--

CREATE TABLE IF NOT EXISTS `timesheetitem` (
  `TimesheetItemId` int(11) NOT NULL AUTO_INCREMENT,
  `Day` date NOT NULL,
  `WorkHours` decimal(4,2) NOT NULL,
  `Comment` varchar(50) DEFAULT NULL,
  `TimesheetId` int(11) NOT NULL,
  PRIMARY KEY (`TimesheetItemId`),
  KEY `TimesheetId` (`TimesheetId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=525 ;

--
-- Dumping data for table `timesheetitem`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `Email` varchar(70) DEFAULT NULL,
  `TelephoneNumber` varchar(20) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Gender` varchar(8) NOT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Enabled` tinyint(1) NOT NULL DEFAULT '1',
  `Admin` tinyint(1) NOT NULL DEFAULT '0',
  `JobId` int(11) DEFAULT NULL,
  `ManagerId` int(11) DEFAULT NULL,
  PRIMARY KEY (`UserId`),
  KEY `JobId` (`JobId`),
  KEY `ManagerId` (`ManagerId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserId`, `Username`, `Password`, `FirstName`, `LastName`, `Email`, `TelephoneNumber`, `Address`, `Gender`, `DateOfBirth`, `Enabled`, `Admin`, `JobId`, `ManagerId`) VALUES
(1, 'nedzad', '306f7c8e345a931d3b14590a38ae8806', 'Nedzad', 'Paradzik', 'paradzik.nedzad@gmail.com', '', 'asdasd', 'MALE', NULL, 1, 0, 3, NULL),
(2, 'nelson', 'a4e360681676c770121e891f8c407572', 'Nelson', 'Mandela', '', '', '', 'MALE', NULL, 1, 0, NULL, 1),
(3, 'test', '98f6bcd4621d373cade4e832627b4f6', 'Test', 'Test', 'p_nedzad@hotmail.com', '', '', 'MALE', '2006-06-29', 1, 0, NULL, 1),
(4, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', 'Admin', '', '', '', 'MALE', NULL, 1, 1, NULL, NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity`
--
ALTER TABLE `activity`
  ADD CONSTRAINT `activity_ibfk_1` FOREIGN KEY (`ProjectId`) REFERENCES `project` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job`
--
ALTER TABLE `job`
  ADD CONSTRAINT `job_ibfk_1` FOREIGN KEY (`OrganizationId`) REFERENCES `organization` (`OrganizationId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `leave`
--
ALTER TABLE `leave`
  ADD CONSTRAINT `leave_ibfk_1` FOREIGN KEY (`LeaveTypeId`) REFERENCES `leavetype` (`LeaveTypeId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `leave_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `user` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `leavebalance`
--
ALTER TABLE `leavebalance`
  ADD CONSTRAINT `leavebalance_ibfk_1` FOREIGN KEY (`LeaveTypeId`) REFERENCES `leavetype` (`LeaveTypeId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `leavebalance_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `user` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project`
--
ALTER TABLE `project`
  ADD CONSTRAINT `project_ibfk_1` FOREIGN KEY (`ProjectAdmin`) REFERENCES `user` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheet`
--
ALTER TABLE `timesheet`
  ADD CONSTRAINT `timesheet_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `user` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `timesheet_ibfk_2` FOREIGN KEY (`ProjectId`) REFERENCES `project` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `timesheet_ibfk_3` FOREIGN KEY (`ActivityId`) REFERENCES `activity` (`ActivityId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheetitem`
--
ALTER TABLE `timesheetitem`
  ADD CONSTRAINT `timesheetitem_ibfk_1` FOREIGN KEY (`TimesheetId`) REFERENCES `timesheet` (`TimesheetId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`JobId`) REFERENCES `job` (`JobId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`ManagerId`) REFERENCES `user` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
